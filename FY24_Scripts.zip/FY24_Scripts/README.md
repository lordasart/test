# ai4g4g
Models and ETL scripts for G4G ACV Predictions
