import pandas as pd
import sys,time,logging,json,os
import traceback

from pkg_resources import run_script
import util.smds_utils as utl
import etl.data_utils as dtl



def upload():
    '''
    '''
    logging.info(script_name+' - Upload predictions to database...')
    tmr = utl.PrettyPrintTimer(True)
    time.sleep(2)
    logging.info(script_name+' - Upload completed - '+tmr.get_duration())
    tmr = None


def build_expl():
    '''
    '''
    logging.info(script_name+' - Build model explanations...')
    tmr = utl.PrettyPrintTimer(True)
    time.sleep(2)
    logging.info(script_name+' - Explanations completed - '+tmr.get_duration())
    tmr = None

def build_stats():
    '''
    '''
    logging.info(script_name+' - Build stats..')
    tmr = utl.PrettyPrintTimer(True)
    time.sleep(2)
    logging.info(script_name+' - Stats completed - '+tmr.get_duration())
    tmr = None

def run_pred():
    '''
    '''
    logging.info(script_name+' - Run Pred...')
    tmr = utl.PrettyPrintTimer(True)
    time.sleep(2)
    logging.info(script_name+' - Predictions completed - '+tmr.get_duration())
    tmr = None

def run_kfold():
    '''
    '''
    logging.info(script_name+' - Run Kfold...')
    tmr = utl.PrettyPrintTimer(True)
    time.sleep(2)
    logging.info(script_name+' - Kfold completed - '+tmr.get_duration())
    tmr = None

def best_hyper_params():
    '''
    '''
    logging.info(script_name+' - Finding optimal hyper-params...')
    tmr = utl.PrettyPrintTimer(True)
    time.sleep(2)
    logging.info(script_name+' - Hyper params completed - '+tmr.get_duration())
    tmr = None


def build_features():
    '''
    '''
    logging.info(script_name+' - Build features...')
    tmr = utl.PrettyPrintTimer(True)
    time.sleep(2)
    logging.info(script_name+' - Features completed - '+tmr.get_duration())
    tmr = None


def collect_data(models_to_run,snap_months,env_config,run_config,refresh_snaps,run_queries):
    '''
    '''
    logging.info(script_name+' - Begin ETL...')
    tmr = utl.PrettyPrintTimer(True)
    dtl.run_etl(models_to_run,snap_months,env_config,run_config,refresh_snaps,run_queries)
    
    logging.info(script_name+' - ETL completed - '+tmr.get_duration())
    tmr = None



def run_acv_predict(run_config,models,snap_months,log_level=logging.INFO ,config_file='acv_fy_predict.json'):
    '''
    Run etl: ./acv_predict.sh -e CORE "20221101"

    '''
    logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s',level=log_level)
    logging.info('Module acv_fy_predict initializing:')
    for k in run_config.keys():
        logging.info('Run config - '+k+': \t'+str(run_config[k]))
    logging.info('Models to run: '+models)
    logging.info('Snap months: '+snap_months) 

    # Model and env. config
    conf = utl.ModuleConfig(script_name,config_file,init_call=True)

   
    # Run sub-modules
    if run_config['ETL'] == True:
 
        refresh_snaps = False
        if run_config['Refresh'] == True:
            refresh_snaps = True
       
        run_queries = False
        if run_config['Queries'] == True:
            run_queries = True
        
        collect_data(models,snap_months,conf,run_config,refresh_snaps,run_queries)


    if run_config['Feat'] == True:
        build_features()

    if run_config['H-Params'] == True:
        best_hyper_params()


    if run_config['Kfold'] == True:
        run_kfold()

    if run_config['Pred'] == True:
        run_pred()

    if run_config['Stats'] == True:
        build_stats()

    if run_config['Expl'] == True:
        build_expl()

    if run_config['Upload'] == True:
        upload()


## Script execution
try:
    
    script_name = os.path.basename(__file__)
    run_config = json.loads(sys.argv[1]) # Load first input as json string 

    if len(sys.argv)<3:
         print('Must include model names! For example: CORE|MC|CC')
    if len(sys.argv)<4:
         print('Must include snap months! For example: 2022-01-01|2022-02-01')
    # elif len(sys.argv)<5:
    #     run_acv_predict(run_config,sys.argv[2],sys.argv[3])
    else:
        run_acv_predict(run_config,sys.argv[2],sys.argv[3])
except Exception as err:
    traceback.print_exc()
    

print('Script acv_fy_predict.fy completed.')