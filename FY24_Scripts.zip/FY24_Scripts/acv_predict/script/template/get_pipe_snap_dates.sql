select /*+parallel(16)*/ distinct snap_date from gpsa.pipe_quality_weekly
where snap_date > date '2018-01-01' order by 1 desc