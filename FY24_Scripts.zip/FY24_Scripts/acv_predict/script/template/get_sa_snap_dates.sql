select /*+parallel(16)*/ distinct ACTIVITY_MONTH as snap_date from SA_FEATURE_FIRST_PHASE
where ACTIVITY_MONTH > date '2018-01-01'
order by ACTIVITY_MONTH desc