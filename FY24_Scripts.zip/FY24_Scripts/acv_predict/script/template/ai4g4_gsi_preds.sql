select
DATA_ASOF_DATE
,case when DATA_ASOF_DATE = date '%GSI_M2' then -2 
when DATA_ASOF_DATE = date '%GSI_M1' then -1
when DATA_ASOF_DATE = date '%GSI_M0' then 0
else -99 end as pred_fy_cd
,acct_id
,acct_acv_potential
from BDS_OPS.UF_ACCT_ACV_MONTHLY
where  DATA_ASOF_DATE in (date '%GSI_M2', date '%GSI_M1', date '%GSI_M0')