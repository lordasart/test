select /*parallel(16)*/
o.ACCT_ID
,o.fiscal_yr_num
,o.converted_amt
,o.opty_id
,o.dim_opty_ky
,o.clsd_dt
,o.clsd_flg
,o.CURR_REC_FLG
,o.won_flg
,o.prim_prod_int
,o.init_prod_int
,p.PROD_ID
,p.L1_BUS_LN
,p.DRVD_PROD_LVL_1
,p.SKU_CD
from dm.DIM_OPPORTUNITY o join dm.FACT_OPPORTUNITY_LINE l on o.OPTY_ID_15 = l.OPTY_ID
join dm.dim_product p on l.prod_ky = p.dim_prod_ky
where o.STG_2_FLG_DT is not null and o.STG_2_FLG_DT between date '2016-02-01' and date '2022-10-31'
and l.CURR_REC_FLG = 'Y'
and o.CURR_REC_FLG = 'Y'
