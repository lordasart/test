SELECT
CASE WHEN DT_KEY = DATE '%T_M0Y' THEN 0
    WHEN DT_KEY = DATE '%T_M1Y' THEN -1
    WHEN DT_KEY = DATE '%T_M2Y' THEN -2
    ELSE -99
    END AS PRED_FY_CD
,A.*
FROM(
SELECT
ACCT_ID
,DT_KEY
,drvd_prod_lvl_1
,drvd_prod_lvl_2
,drvd_prod_lvl_3
,SUM(ALLOC_AOV) ALLOC_AOV
FROM dm.FACT_AOV_SS
WHERE DT_KEY IN (DATE '%T_M0Y',DATE '%T_M1Y',DATE '%T_M2Y')
GROUP BY 
ACCT_ID
,DT_KEY
,drvd_prod_lvl_1
,drvd_prod_lvl_2
,drvd_prod_lvl_3)A
