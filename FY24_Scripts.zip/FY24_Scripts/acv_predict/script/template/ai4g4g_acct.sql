select
a.acct_id
,a.combo_company_id
,a.region
,a.LOCKED_INDUSTRY
,a.LOCKED_SECTOR
,a.derived_sub_sector
,a.lck_emp_cnt
,a.territory_name
,a.website_status
,a.new_logo_eligible
,a.PTB_MKT_SEGMENT
,a.aov_amt
,a.state_nm
,a.country_iso_code
,a.drvd_postal_cd
,a.top_city
from bds_ops.ai_account_master a
