select /*+parallel(16)*/
case 
     when a.data_asof_date = date '%PTB_CUST_M2' then -2
     when a.data_asof_date = date '%PTB_CUST_M1' then -1
     when a.data_asof_date = date '%PTB_CUST_M0' then 0
    else -99 end as pred_fy_cd
,a.*
from (select
data_asof_date
,acct_id
,cloud
,ptb_product
,max(revised_star) revised_star
,max(revised_score) revised_score
from BDS_OPS.UF_ORG62_INTERMEDIATE
where data_asof_date in (date '%PTB_CUST_M0',date '%PTB_CUST_M1',date '%PTB_CUST_M2')
group by data_asof_date ,acct_id,cloud,ptb_product)a
