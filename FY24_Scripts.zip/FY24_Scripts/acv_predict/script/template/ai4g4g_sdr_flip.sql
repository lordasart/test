select
o.stg_2_flg_dt
,case when extract(month from stg_2_flg_dt)=1 then extract(year from stg_2_flg_dt)
else extract(year from stg_2_flg_dt)+1 end as stg_2_flg_fy
,case when extract(month from stg_2_flg_dt)=1 then 12
else extract(month from stg_2_flg_dt)-1 end as stg_2_flg_fy_mnth
,o.acct_id
,a.lck_emp_cnt
,o.OPTY_ID
,o.OPTY_SRC_NM
,o.won_amt
,o.CMPTTVE_STAT
from dm.DIM_OPPORTUNITY o join bds_ops.ai_account_master a on o.ACCT_ID = a.ACCT_ID
where OPTY_SRC_NM = 'SDR' and STG_2_FLG_DT >= date '2015-02-01'
