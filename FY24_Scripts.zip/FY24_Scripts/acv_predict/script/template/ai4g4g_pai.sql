select /*+parallel(16)*/
case when a.data_asof_date = date '2019-12-01' then 2020
     when a.data_asof_date = date '2020-10-01' then 2021
     when a.data_asof_date = date '2021-10-01' then 2022
     when a.data_asof_date = date '2022-09-01' then 2023
    else -1 end as snap_fy
,case when a.data_asof_date = date '2019-12-01' then 2021
     when a.data_asof_date = date '2020-10-01' then 2022
     when a.data_asof_date = date '2021-10-01' then 2023
     when a.data_asof_date = date '2022-09-01' then 2024
    else -1 end as pred_fy
,a.*
from (select
data_asof_date
,acct_id
,cloud
,ptb_product
,max(revised_star) revised_star
,max(revised_score) revised_score
from BDS_OPS.UF_ORG62_INTERMEDIATE_PAI
where data_asof_date in (date '2019-12-01',date '2020-10-01',date '2021-10-01',date '2022-09-01')
group by data_asof_date ,acct_id,cloud,ptb_product)a
