
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE zzs_pipegen';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@

create table zzs_pipegen as
select
a.*
,case when clsd_fy>=fiscal_yr_num and clsd_dt_fy_month > 11 then 1 else 0 end flg_open_at_pred
from (
select
acct_id
,fiscal_yr_num
,stg_2_flg_dt
,case when extract(month from stg_2_flg_dt)=1 then 12 else extract(month from stg_2_flg_dt)-1 end
as stg_2_flg_fy_month
,clsd_dt
,case when clsd_dt is null then 9999 else
extract(year from clsd_dt)+1 end as clsd_fy
,case when extract(month from clsd_dt)=1 then 12 else extract(month from clsd_dt)-1 end
as clsd_dt_fy_month
,won_flg
,forcst_cat_cd
,probability_pct
,pipegen_amt_usd
from BDS_OPS.AI_PIPEGEN where fiscal_yr_num>=2016 and fiscal_yr_num<2025)a
@

select * from zzs_pipegen
