
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE zzs_sa_01';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@


create table zzs_sa_01 as
select /*+parallel(16)*/
A.*
,case when activity_month between date '%SA_M0' and  ADD_MONTHS(date '%SA_M0', -3) then 0 
when activity_month between date '%SA_M1' and  ADD_MONTHS(date '%SA_M1', -3) then -1 
when activity_month between date '%SA_M2' and  ADD_MONTHS(date '%SA_M2', -3) then -2 
else -99 end as pred_fy_cd
,CASE WHEN EXTRACT(month FROM activity_month) = 1 THEN EXTRACT(YEAR FROM activity_month) + 1
    ELSE EXTRACT(YEAR FROM activity_month) + 2  END AS PRED_FY
from SA_FEATURE_FIRST_PHASE a
where activity_month in (date '%SA_M0',ADD_MONTHS(date '%SA_M0', -1),ADD_MONTHS(date '%SA_M0', -2),ADD_MONTHS(date '%SA_M0', -3)
                        ,date '%SA_M1',ADD_MONTHS(date '%SA_M1', -1),ADD_MONTHS(date '%SA_M1', -2),ADD_MONTHS(date '%SA_M1', -3)
                        ,date '%SA_M2',ADD_MONTHS(date '%SA_M2', -1),ADD_MONTHS(date '%SA_M2', -2),ADD_MONTHS(date '%SA_M2', -3))
@


BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE zzs_sa_AGG_01';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@


CREATE TABLE zzs_sa_AGG_01
AS SELECT
ACCT_ID
,pred_fy_cd
,PRED_FY
,AVG(SA_EMAIL_VP) SA_EMAIL_VP
,AVG(SA_EMAIL_NVP) SA_EMAIL_NVP
,AVG(SA_CONNECT_VP) SA_CONNECT_VP
,AVG(SA_CONNECT_NVP) SA_CONNECT_NVP
,AVG(SA_CALL_VP) SA_CALL_VP
,AVG(SA_CALL_NVP) SA_CALL_NVP
,AVG(SA_MEET_VP) SA_MEET_VP
,AVG(SA_MEET_NVP) SA_MEET_NVP
,AVG(SA_EMAIL) SA_EMAIL
,AVG(SA_CONNECT) SA_CONNECT
,AVG(SA_CALL) SA_CALL
,AVG(SA_MEET) SA_MEET
FROM zzs_sa_01
GROUP BY
ACCT_ID
,pred_fy_cd
,PRED_FY
@

select * from zzs_sa_AGG_01
