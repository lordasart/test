select
snap_date
,case when snap_date = date '%PIPE_M2' then -2 
when snap_date = date '%PIPE_M1' then -1
when snap_date = date '%PIPE_M0' then 0
else -99 end as pred_fy_cd
,acct_id
,opty_src_nm
,opty_stg_nm
,clsd_dt
,push_ctr
,apm_level_1
,apm_level_2
,apm_level_3
,apm_lvl1_opty_amt
,apm_lvl3_opty_amt
,opty_ind
,opty_ind_detail
,cc_flg
,is_pipegen
,opty_stg_nm
,days_since_opty_touched
,total_next_steps
,nvl(comp_status,'Unknown') comp_status
,curr_opty_amt
,curr_opty_clsd_flg
,curr_opty_push_ctr
,curr_opty_src_nm
FROM gpsa.pipe_quality_weekly where snap_date in
(date '%PIPE_M0',date '%PIPE_M1', date '%PIPE_M2')
