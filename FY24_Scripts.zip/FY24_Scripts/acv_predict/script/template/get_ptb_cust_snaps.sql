select /*+parallel(16)*/ distinct DATA_ASOF_DATE SNAP_DATE from BDS_OPS.UF_ORG62_INTERMEDIATE
order by 1 desc