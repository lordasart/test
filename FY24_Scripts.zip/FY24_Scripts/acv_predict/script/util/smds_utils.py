import time,json,sys,getpass,os,logging

class PrettyPrintTimer:

	start_time = 0

	def __init__(self, init_timer = True):
		if init_timer:
			self.reset_timer()


	def reset_timer(self):
		self.start_time = time.time()
		

	def get_duration(self):
		seconds = time.time() - self.start_time
		if seconds >= 3600:
			hours = int(seconds / 3600)
			seconds = seconds - hours * 3600
			minutes = int(seconds / 60)
			seconds = int(seconds - minutes * 60)
			hrs = 'hours'
			mins = 'minutes'
			secs = 'seconds'
			if hours == 1:
				hrs = 'hour'
			if minutes == 1:
				mins = 'minute'
			if seconds == 1:
				secs = 'second'
			return 'Duration: {} '+hrs+', {} '+mins+', {} '+secs+'.'.format(hours,minutes,seconds)
		elif seconds >= 60:
			minutes = int(seconds / 60)
			seconds = int(seconds - minutes * 60)
			return 'Duration: {} '+mins+', {} '+secs+'.'.format(minutes,seconds)
		else:
			seconds = int(seconds)
			return 'Duration: {} '+secs+'.'.format(seconds)

            
class ModuleConfig:
	'''
	Base Config + overriding
	'''

	cfg_dict =  {}
	def __init__(self, module_name, config_path,init_call=False):
		config_path = config_path.replace('%user_name',getpass.getuser())
		if not os.path.exists(config_path):
			raise Exception ('Cannot find global configuration file: '+str(config_path))
		
		self.cfg_dict = json.loads(open(config_path).read())

		if init_call:
			for key in self.cfg_dict:
				logging.info('Config params:  - ' + key + ': ' + str(self.cfg_dict[key]))
	

	def get_config(self,conf_name, fail_if_none=True):
		config = self.cfg_dict.get(conf_name)
		if config is None and fail_if_none:
			raise Exception ('ModuleConfig - Cannot find value for conf param: '+str(conf_name))
		if(type(config)==str): # handle path variables
			config = config.replace('%user_name',getpass.getuser())

		return config