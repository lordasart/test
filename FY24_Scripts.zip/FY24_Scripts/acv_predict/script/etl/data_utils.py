'''
	ACV Prediction model based on GSI and Pricing models + trailing ACV. 
	
	Functions for running ETL and data cleanup.
	Initial version: 12/3/2021

'''
from datetime import datetime
from dateutil.relativedelta import relativedelta
import pandas as pd
import getpass
import json
import sys,os,logging
import warnings
import traceback
warnings.filterwarnings("ignore")




def build_query_file(template_file,target_file,values_map):
	'''
	Converts template SQL files into runnable SQL

	Parameters:
		template_file - full name of template file
		target_file - full name of target file
		target_file - dictionary with find/replace pairs.  

	Return:
		Null

	'''
	with open(target_file, 'w') as fw:
		with open(template_file, 'r') as tr:
			for line in tr.readlines():
				for key in values_map.keys():
					line = line.replace(key,values_map[key])
				fw.write(line)




def build_t_minus_dates(start_date_str,date_format,num_years,add_TM0_date=False):
	'''
	Utility for building rolling dates based on a given start snap month. These values are used when building SQL files from the
	templates. 

	Parameters:
		start_date - The run-as snap month
		date_format - Date format used the SQL files
		num_years - Number of years to roll back
		add_TM0_date - Add a mapping for T minus 0 to T plus 1 years. (This is used for validation.) 

	Return:
		A dictionary with tag/date values.  

	'''
	date_templ_dir = {}
	if add_TM0_date == True:
		date_templ_dir[f'%T_P1Y'] = (datetime.strptime(start_date_str, date_format).date() + relativedelta(years= 1)).strftime(date_format)
		date_templ_dir[f'%INTR_T_P1Y_END'] = (datetime.strptime(start_date_str, date_format).date() + relativedelta(years= 1)).strftime(date_format)
		date_templ_dir[f'%INTR_T_P1Y_START'] = (datetime.strptime(start_date_str, date_format).date() ).strftime(date_format)
	for t in range(num_years):
		date_templ_dir[f'%T_M{t}Y'] = (datetime.strptime(start_date_str, date_format).date() - relativedelta(years= t)).strftime(date_format)
		date_templ_dir[f'%INTR_T_M{t}Y_END'] = (datetime.strptime(start_date_str, date_format).date() - relativedelta(years= t)).strftime(date_format)
		date_templ_dir[f'%INTR_T_M{t}Y_START'] = (datetime.strptime(start_date_str, date_format).date() - relativedelta(years= t+1) ).strftime(date_format)

	return date_templ_dir



def get_gsi_dates(values_map,df):
	'''
	Utility to figure out the dates for which we have a GSI model prediction. If we don't have a prediction for a given month, we try 
	to find the latest prediction month in the past. 

	Parameters:
		values_map - tag/date directory. (Typically built with  build_t_minus_dates())
		df - data frame with GSI model run dates. Column for run date shold be called "DATA_ASOF_DATE"

	Return:
		Directory with available GSI prediction dates. 

	'''
	# df = df.sort_values(by='DATA_ASOF_DATE',ascending=True)
	# gsi_snap_map = {}
	# snap_counter = []
	# for key in values_map.keys():
	# 	if not key[0:3] == '%T_':
	# 		continue

	# snap_counter = snap_counter + [key]
	# for index, row in df.iterrows():
		# dt = datetime.strptime(row['DATA_ASOF_DATE'][0:10], '%Y-%m-%d')
		# if dt < datetime.strptime(values_map[key], '%Y-%m-%d'):
		#   gsi_snap_map[key] = (values_map[key],row['DATA_ASOF_DATE'][0:10])

	# assert (len(set(snap_counter) - set(gsi_snap_map.keys())) == 0), "Cannot find GSI predictions for snaps:" + str(set(snap_counter) - set(gsi_snap_map.keys()))
	# return gsi_snap_map

def get_ptb_dates(values_map,df):
	'''
	Utility to figure out the dates for which we have a PTB model predictions. If we don't have a prediction for a given month, we try 
	to find the latest prediction month in the past. 

	Parameters:
		values_map - tag/date directory. (Typically built with  build_t_minus_dates())
		df - data frame with PTB model run dates. Column for run date should be called "DATA_ASOF_DATE"

	Return:
		Directory with available PTB prediction dates. 

	'''
	df = df.sort_values(by='SNAP_DATE',ascending=False)
	
	ptb_snap_map = {}
	snap_counter = []
	for key in values_map.keys():
		if not key[0:3] == '%T_':
			continue

		snap_counter = snap_counter + [key]
		for index, row in df.iterrows():
			dt = datetime.strptime(row['SNAP_DATE'][0:10], '%Y-%m-%d')
			if dt < datetime.strptime(values_map[key], '%Y-%m-%d'):
				ptb_snap_map[key] = (values_map[key],row['SNAP_DATE'][0:10])
				break

	
	assert (len(set(snap_counter) - set(ptb_snap_map.keys())) == 0), "Cannot find data for snaps:" + str(set(snap_counter) - set(ptb_snap_map.keys()))
	
	return ptb_snap_map



def check_and_create_dir(file_path):
	'''
	Utility for building a directory path, if the given path does not already exist.
	
	Parameters:
		file_path - requested path
	Return:
		Null

	'''
	if not os.path.exists(file_path):
		try:
			os.makedirs(file_path)
			logging.info('Created directory: '+file_path)
		except Exception as err:
			logging.info('Not creating directory: '+file_path+' - '+err)
			return


def add_date_mappings(values_map,date_templ_map,snap_dates_dir_path):
	'''
	Maps data template placeholders for query dates. 
	'''

	for key in date_templ_map.keys():
		logging.info('Date template: '+key+' - '+date_templ_map[key])
		tmpl_txt = date_templ_map[key]
		df_snaps = pd.read_csv(snap_dates_dir_path + key)
		dates_map = get_ptb_dates(values_map,df_snaps)
		cntr = 0
		for k in dates_map.keys():
			values_map[tmpl_txt+str(cntr)] = dates_map[k][1]
			cntr = cntr + 1 

	return values_map

def convert_dates(dt_string,flg_to_long=True):
    '''
    Converts date string between formats "YYYYMMDD" and "YYYY-MM_DD".
    '''
    if flg_to_long == True:
        if len(dt_string) != 8:
            raise ValueError('Bad input for date conversion into dashed format: '+dt_string)
        return dt_string[0:4]+'-'+dt_string[4:6]+'-'+dt_string[6:8]
    else:
        if len(dt_string) != 10:
            raise ValueError('Bad input for date conversion into compact format: '+dt_string)
        return dt_string.replace('-','')


def run_etl(models_to_run,snap_months,run_config,module_config,get_snap_dates=False,run_queries=False):
	
	logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s',level=logging.INFO)
	snap_month_input = snap_months
	logging.info('snap_month_input: '+snap_month_input)

	snap_months = snap_month_input.split('|')
	logging.info('Running snaps: '+str(snap_months))
	logging.info('models_to_run: '+str(models_to_run))
	logging.info('run_config: '+str(run_config))
	logging.info('module_config: '+str(module_config))
	logging.info('run_queries: '+str(run_queries))
	logging.info('get_snap_dates: '+str(get_snap_dates))


	for snap_month in snap_months:
		logging.info('Starting snap: '+snap_month)


		# Set run params
		date_format = "%Y-%m-%d"
		t_m0_date = convert_dates(snap_month,flg_to_long=True)
		logging.info('T minus zero date: '+t_m0_date)
		snap_dir = t_m0_date.replace('-','') + '/'

		user_name = getpass.getuser()
		smds_lib_path = run_config.get_config('smds_lib_path').replace('%user_name', user_name)
		ai4g_home = run_config.get_config('ai4g4g_home').replace('%user_name', user_name)
		cred_file_path = run_config.get_config('cred_file_path').replace('%user_name', user_name)
		snap_dir_path = run_config.get_config('data_home') + run_config.get_config('dump_dir') + snap_dir 
		sql_dir_path = run_config.get_config('data_home') + run_config.get_config('sql_dir') + snap_dir 
		template_dir_path  = run_config.get_config('code_home') + run_config.get_config('template_dir')
		snap_dates_dir_path  = run_config.get_config('data_home') + run_config.get_config('snaps_dir')

	
		logging.info('Template dir path: '+template_dir_path)
		logging.info('SQL dir path: '+sql_dir_path)
		logging.info('Dump dir path: '+snap_dir_path)

		# Create data directories
		check_and_create_dir(snap_dir_path)
		check_and_create_dir(sql_dir_path)

		if get_snap_dates == True:
			logging.info('smds_lib_path: '+smds_lib_path)
			sys.path.append(smds_lib_path)
			import db_etl as etl

			# Figure out available snap dates for source data
			date_qry_csv_map = run_config.get_config('date_qry_csv_map')
			snap_dt_query_files = list(date_qry_csv_map.keys())

			# Move templates directly to sql directory and run results
			for qry_file in snap_dt_query_files:
				srcfile = template_dir_path + qry_file
				tgtfile = sql_dir_path + qry_file
				csv_file_name  = qry_file[4:].split('.')[0]+'.csv'
				logging.info('Getting snapp dates into: '+csv_file_name)
				build_query_file(srcfile,tgtfile,{})

				gsi_query = tgtfile
				db_connection = etl.DB_ETL(cred_file_path)
				cursor = db_connection.oracle_connection()

				db_connection.run_sql_to_disk(cursor, gsi_query, snap_dates_dir_path+csv_file_name, True, ',',print_debug=True)
				cursor.close()
				logging.info('Loaded source data snaps into '+snap_dates_dir_path+csv_file_name)
		else:
			logging.warning('Not loading latest snap dates.')


	  # Map snap dates
		num_hist_snaps = 	run_config.get_config('num_hist_snaps')
		values_map = build_t_minus_dates(t_m0_date,date_format,num_hist_snaps,add_TM0_date=False)
		logging.info('Values map: '+str(values_map))

		# Add date template mappings for all queries
		date_templ_mappings = run_config.get_config('date_templ_mappings')
		values_map = add_date_mappings(values_map,date_templ_mappings,snap_dates_dir_path)
		
		
		# Build queries from template files
		query_templates_list = run_config.get_config('query_templates').split(',')
		for query_templ in query_templates_list:
			srcfile = template_dir_path + query_templ
			tfile_train_query = sql_dir_path + query_templ
			build_query_file(srcfile,tfile_train_query,values_map)
			logging.info('Query file built as: '+tfile_train_query)

		
		
		if run_queries == True:
			sys.path.append(smds_lib_path)
			import db_etl as etl
		
			for query in query_templates_list:
				csv_file = query.split('.')[0]
				print('csv_file:',csv_file)
				db_connection = etl.DB_ETL(cred_file_path)
				cursor = db_connection.oracle_connection()
				db_connection.run_sql_to_disk(cursor, sql_dir_path+query, snap_dir_path+csv_file+'_'+t_m0_date+ '.csv', True, ',',print_debug=True)
				cursor.close()
				print('Completed',csv_file)

	
		logging.info('Done with snap '+snap_month+'.')









