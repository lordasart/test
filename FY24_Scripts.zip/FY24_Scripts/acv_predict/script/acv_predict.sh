#!/bin/bash

################## Options #######################################
show_help()
{
   echo "Usage: acv_predict [-h|P|C|r|q|e|f|y|k|p|s|x|u] [config file name] [models] [snaps]"
   echo "Options:"
   echo "h     Print this help message"
   echo "P     Predict/stats for prospect accounts"
   echo "C     Predict/stats for customer accounts"
   echo "r     Refresh snap dates"
   echo "q     Only build ETL queries"
   echo "e     Run ETL scripts"
   echo "f     Build features"
   echo "y     Optimize hyper params"
   echo "k     Run K-fold"
   echo "p     Run predictions"
   echo "s     Build model stats"
   echo "x     Build model explanations"
   echo "u     Upload predictions to database"
   echo "[config file name]  Config file name (assumed to be in the local directory)    "
   echo "[models]  Any combination of CORE,MC,CC"
   echo "[snaps]  Snap month list, for example: \"2022-01-01|2022-02-01|2022-03-01\""
   
}

################## Run params ####################################
do_run="No"
refresh="false"
queries="false"
etl="false"
features="false"
hyper_params="false"
kfold="false"
prosp="false"
cust="false"
predict="false"
stats="false"
expl="false"
upload="false"
models=$2
snaps=$3
config=$4

################## Python calls - (main logic) ##################
run_models()
{
    echo "Starting AI4G4G ACV predict script" 
    echo "Options:"
    echo "1 - Run for prospects: [$prosp]"
    echo "2 - Run for customers: [$cust]"
    echo "3 - Refresh snaps: [$refresh]"
    echo "4 - Only build queries: [$queries]"
    echo "5 - Run ETL: [$etl]"
    echo "6 - Build features: [$features]"
    echo "7 - Find hyper-params: [$hyper_params]"
    echo "8 - Run K-fold: [$kfold]"
    echo "9 - Run predictions: [$predict]"
    echo "10 - Build model stats: [$stats]"
    echo "11 - Build model explanations: [$expl]"
    echo "12 - Upload to Database: [$expl]"
    echo "Config file: $config"
    echo "Models to run: $models"
    echo "Snap months: $snaps"

    python3 acv_fy_predict.py "{\"Prosp\":$prosp,\"Cust\":$cust,\"Refresh\":$refresh,\"Queries\":$queries,\"ETL\":$etl,\"Feat\":$features,\"H-Params\":$hyper_params,\"Kfold\":$kfold,\"Pred\":$predict,\"Stats\":$stats,\"Expl\":$expl,\"Upload\":$upload}" $models $snaps $config
}

################## Handle options ################################
while getopts ":hqrefhkyPCpsxu" option; do
   case $option in
      h) 
         show_help
         exit;;
      q)
        queries="true"
        do_run="Run";;
      r)
        refresh="true"
        do_run="Run";;
      e)
        etl="true"
        do_run="Run";;
      f)
        features="true"
        do_run="Run";;
      y)
        hyper_params="true"
        do_run="Run";;
      k)
        kfold="true"
        do_run="Run";;
      P)
        prosp="true"
        do_run="Run";;
      C)
        cust="true"
        do_run="Run";;
      p)
        predict="true"
        do_run="Run";;
      s)
        stats="true"
        do_run="Run";;
      x)
        expl="true"
        do_run="Run";;
      u)
        upload="true"
        do_run="Run";;
      \?) 
         echo "Error: Invalid option"
        exit;;  
 
   esac
done



run_val="Run"
if [[ "$do_run" == "$run_val" ]]; then
    run_models
else
    show_help
fi

