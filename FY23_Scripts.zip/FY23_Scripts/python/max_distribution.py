import pandas as pd
import numpy as np
## Copied from "FY22 AI for G4G Backtesting Framework"
## https://git.soma.salesforce.com/Business-Data-Science/Quota-distribution-prediction/blob/master/Backtest%20Framework%20FY22.ipynb 

# Slight change adding MinGrp2Pred used for optimization
def dist_error(group_col1, group_col2, pred,actual, data, pred2 = 'none', gss1 = 'none', gss2 = 'none', gss3 = 'none', gss4 = 'none', gss5 = 'none', gss6 = 'none', gss7 = 'none', gss8 = 'none', gss9 = 'none'): 
    df_grouped = data.groupby([group_col1, group_col2])[actual, pred].sum()
    df_dist =  df_grouped.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
    df_dist['error'] = abs(df_dist[actual]-df_dist[pred])
    ttl_err = df_dist.groupby(group_col1).agg({'error':'sum'})
    avg_err = np.mean(ttl_err)
    err_dict = {"Pred 1": "{:.1%}".format(avg_err[0]/100)}
    err_dict["Pred 1 (raw)"] = avg_err[0]/100
    if pred2 != 'none':
        pred2_grp = data.groupby([group_col1, group_col2])[actual, pred2].sum()
        pred2_dist = pred2_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        pred2_dist['error'] = abs(pred2_dist[actual]-pred2_dist[pred2])
        ttl_err_pred2 = pred2_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_pred2  = np.mean(ttl_err_pred2)
        err_dict["Pred 2"] = "{:.1%}".format(avg_err_pred2[0]/100)
        err_dict["Pred 2 (raw)"] = avg_err_pred2[0]/100
        df_dist['Pred_2_Dist'] = pred2_dist[pred2]
        df_dist['Pred_2_Err'] = pred2_dist['error']
    if gss1 != 'none': 
        gss1_grp = data.groupby([group_col1, group_col2])[actual, gss1].sum()
        gss1_dist = gss1_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss1_dist['error'] = abs(gss1_dist[actual]-gss1_dist[gss1])
        ttl_err_gss1 = gss1_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss1  = np.mean(ttl_err_gss1)
        err_dict["GSS 1"] = "{:.1%}".format(avg_err_gss1[0]/100)
        err_dict["GSS 1 (raw)"] = avg_err_gss1[0]/100
        df_dist['GSS_1_Dist'] = gss1_dist[gss1]
        df_dist['GSS_1_Err'] = gss1_dist['error']
    if gss2 != 'none': 
        gss2_grp = data.groupby([group_col1, group_col2])[actual, gss2].sum()
        gss2_dist = gss2_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss2_dist['error'] = abs(gss2_dist[actual]-gss2_dist[gss2])
        ttl_err_gss2 = gss2_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss2  = np.mean(ttl_err_gss2)
        err_dict["GSS 2"] = "{:.1%}".format(avg_err_gss2[0]/100)
        err_dict["GSS 2 (raw)"] = avg_err_gss2[0]/100
        df_dist['GSS_2_Dist'] = gss2_dist[gss2]
        df_dist['GSS_2_Err'] = gss2_dist['error']
    if gss3 != 'none': 
        gss3_grp = data.groupby([group_col1, group_col2])[actual, gss3].sum()
        gss3_dist = gss3_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss3_dist['error'] = abs(gss3_dist[actual]-gss3_dist[gss3])
        ttl_err_gss3 = gss3_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss3  = np.mean(ttl_err_gss3)
        err_dict["GSS 3"] = "{:.1%}".format(avg_err_gss3[0]/100)
        err_dict["GSS 3 (raw)"] = avg_err_gss3[0]/100
        df_dist['GSS_3_Dist'] = gss3_dist[gss3]
        df_dist['GSS_3_Err'] = gss3_dist['error']
    if gss4 != 'none': 
        gss4_grp = data.groupby([group_col1, group_col2])[actual, gss4].sum()
        gss4_dist = gss4_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss4_dist['error'] = abs(gss4_dist[actual]-gss4_dist[gss4])
        ttl_err_gss4 = gss4_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss4  = np.mean(ttl_err_gss4)
        err_dict["GSS 4"] = "{:.1%}".format(avg_err_gss4[0]/100)
        err_dict["GSS 4 (raw)"] = avg_err_gss4[0]/100
        df_dist['GSS_4_Dist'] = gss4_dist[gss4]
        df_dist['GSS_4_Err'] = gss4_dist['error']
    if gss5 != 'none': 
        gss5_grp = data.groupby([group_col1, group_col2])[actual, gss5].sum()
        gss5_dist = gss5_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss5_dist['error'] = abs(gss5_dist[actual]-gss5_dist[gss5])
        ttl_err_gss5 = gss5_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss5  = np.mean(ttl_err_gss5)
        err_dict["GSS 5"] = "{:.1%}".format(avg_err_gss5[0]/100)
        err_dict["GSS 5 (raw)"] = avg_err_gss5[0]/100
        df_dist['GSS_5_Dist'] = gss5_dist[gss5]
        df_dist['GSS_5_Err'] = gss5_dist['error']
    if gss6 != 'none': 
        gss6_grp = data.groupby([group_col1, group_col2])[actual, gss6].sum()
        gss6_dist = gss6_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss6_dist['error'] = abs(gss6_dist[actual]-gss6_dist[gss6])
        ttl_err_gss6 = gss6_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss6  = np.mean(ttl_err_gss6)
        err_dict["GSS 6"] = "{:.1%}".format(avg_err_gss6[0]/100)
        err_dict["GSS 6 (raw)"] = avg_err_gss6[0]/100
        df_dist['GSS_6_Dist'] = gss6_dist[gss6]
        df_dist['GSS_6_Err'] = gss6_dist['error']
    if gss7 != 'none': 
        gss7_grp = data.groupby([group_col1, group_col2])[actual, gss7].sum()
        gss7_dist = gss7_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss7_dist['error'] = abs(gss7_dist[actual]-gss7_dist[gss7])
        ttl_err_gss7 = gss7_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss7  = np.mean(ttl_err_gss7)
        err_dict["GSS 7"] = "{:.1%}".format(avg_err_gss7[0]/100)
        err_dict["GSS 7 (raw)"] = avg_err_gss7[0]/100
        df_dist['GSS_7_Dist'] = gss7_dist[gss7]
        df_dist['GSS_7_Err'] = gss7_dist['error']
    if gss8 != 'none': 
        gss8_grp = data.groupby([group_col1, group_col2])[actual, gss8].sum()
        gss8_dist = gss8_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss8_dist['error'] = abs(gss8_dist[actual]-gss8_dist[gss8])
        ttl_err_gss8 = gss8_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss8  = np.mean(ttl_err_gss8)
        err_dict["GSS 8"] = "{:.1%}".format(avg_err_gss8[0]/100)
        err_dict["GSS 8 (raw)"] = avg_err_gss8[0]/100
        df_dist['GSS_8_Dist'] = gss8_dist[gss8]
        df_dist['GSS_8_Err'] = gss8_dist['error']
    if gss9 != 'none': 
        gss9_grp = data.groupby([group_col1, group_col2])[actual, gss9].sum()
        gss9_dist = gss9_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss9_dist['error'] = abs(gss9_dist[actual]-gss9_dist[gss9])
        ttl_err_gss9 = gss9_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss9  = np.mean(ttl_err_gss9)
        err_dict["GSS 9"] = "{:.1%}".format(avg_err_gss9[0]/100)
        err_dict["GSS 9 (raw)"] = avg_err_gss9[0]/100
        df_dist['GSS_9_Dist'] = gss9_dist[gss9]
        df_dist['GSS_9_Err'] = gss9_dist['error']
  
  
    return err_dict, df_dist.style




def dist_ou_wt_err(group_col1, group_col2, data, actual,  cols):
    if data[group_col1].nunique()>1:
        raise Exception("This function works only for group_col1 = OU, (found "+str(data[group_col1].nunique())+") use dist_wt_error function for this mechanism")
    ncols = list(cols)
    if actual not in cols:
        ncols = ncols + [actual]
    # Perform group sum
    df_grouped = data.groupby([group_col1, group_col2])[ncols].sum()
    # Get distribution
    df_dist =  df_grouped.groupby(level=0).apply(lambda x: x / x.sum())
    # Get error distribution wrt actual
    df_dist_err = df_dist.apply(lambda x: x - df_dist[actual]).abs()
    df_dist_err = df_dist_err.drop(actual,1).add_suffix('_raw_err')
       
        
    # wts of actual distrbution by grp2
    actual_wt =  df_dist[actual]/df_dist[actual].sum()
    
    # Wt avg
    res = df_dist_err.apply(lambda x: (x*actual_wt).sum())
    return res.to_dict(), pd.concat([df_dist, df_dist_err],1)


def dist_ou_raw_err(group_col1, group_col2, data, actual,  cols):
    if data[group_col1].nunique()>1:
        raise Exception("This function works only for group_col1 = OU, (found "+str(data[group_col1].nunique())+") use dist_wt_error function for this mechanism")
    ncols = list(cols)
    if actual not in cols:
        ncols = ncols + [actual]
    # Perform group sum
    df_grouped = data.groupby([group_col1, group_col2])[ncols].sum()
    # Get distribution
    df_dist =  df_grouped.groupby(level=0).apply(lambda x: x / x.sum())
    # Get error distribution wrt actual
    df_dist_err = df_dist.apply(lambda x: x - df_dist[actual]).abs()
    df_dist_err = df_dist_err.drop(actual,1).add_suffix('_raw_err')
       
    # Wt avg
    res = df_dist_err.apply(lambda x: x.sum())
    return res.to_dict(), pd.concat([df_dist, df_dist_err],1)
    
    
    
def dist_wt_error(group_col1, group_col2, pred,actual, data, pred2 = 'none', gss1 = 'none', gss2 = 'none', gss3 = 'none', gss4 = 'none', gss5 = 'none', gss6 = 'none', gss7 = 'none', gss8 = 'none', gss9 = 'none'): 
    df_grouped = data.groupby([group_col1, group_col2])[actual, pred].sum()
    df_dist =  df_grouped.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
    df_dist['error'] = abs(df_dist[actual]-df_dist[pred])
    ttl_err = df_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
    avg_err = np.average(ttl_err['error'], weights = ttl_err[actual])
    err_dict = {"Pred 1": "{:.1%}".format(avg_err[0]/100)}
    err_dict["Pred 1 (raw)"] = avg_err[0]/100
    if pred2 != 'none':
        pred2_grp = data.groupby([group_col1, group_col2])[actual, pred2].sum()
        pred2_dist = pred2_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        pred2_dist['error'] = abs(pred2_dist[actual]-pred2_dist[pred2])
        ttl_err_pred2 = pred2_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_pred2  = np.average(ttl_err_pred2['error'], weights = ttl_err_pred2[actual])
        err_dict["Pred 2"] = "{:.1%}".format(avg_err_pred2[0]/100)
        err_dict["Pred 2 (raw)"] = avg_err_pred2[0]/100
        df_dist['Pred_2_Dist'] = pred2_dist[pred2]
        df_dist['Pred_2_Err'] = pred2_dist['error']
    if gss1 != 'none': 
        gss1_grp = data.groupby([group_col1, group_col2])[actual, gss1].sum()
        gss1_dist = gss1_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss1_dist['error'] = abs(gss1_dist[actual]-gss1_dist[gss1])
        ttl_err_gss1 = gss1_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_gss1  = np.average(ttl_err_gss1['error'], weights = ttl_err_gss1[actual])
        err_dict["GSS 1"] = "{:.1%}".format(avg_err_gss1[0]/100)
        err_dict["GSS 1 (raw)"] = avg_err_gss1[0]/100
        df_dist['GSS_1_Dist'] = gss1_dist[gss1]
        df_dist['GSS_1_Err'] = gss1_dist['error']
    if gss2 != 'none': 
        gss2_grp = data.groupby([group_col1, group_col2])[actual, gss2].sum()
        gss2_dist = gss2_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss2_dist['error'] = abs(gss2_dist[actual]-gss2_dist[gss2])
        ttl_err_gss2 = gss2_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_gss2  = np.average(ttl_err_gss2['error'], weights = ttl_err_gss2[actual])
        err_dict["GSS 2"] = "{:.1%}".format(avg_err_gss2[0]/100)
        err_dict["GSS 2 (raw)"] = avg_err_gss2[0]/100
        df_dist['GSS_2_Dist'] = gss2_dist[gss2]
        df_dist['GSS_2_Err'] = gss2_dist['error']
    if gss3 != 'none': 
        gss3_grp = data.groupby([group_col1, group_col2])[actual, gss3].sum()
        gss3_dist = gss3_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss3_dist['error'] = abs(gss3_dist[actual]-gss3_dist[gss3])
        ttl_err_gss3 = gss3_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_gss3  = np.average(ttl_err_gss3['error'], weights = ttl_err_gss3[actual])
        err_dict["GSS 3"] = "{:.1%}".format(avg_err_gss3[0]/100)
        err_dict["GSS 3 (raw)"] = avg_err_gss3[0]/100
        df_dist['GSS_3_Dist'] = gss3_dist[gss3]
        df_dist['GSS_3_Err'] = gss3_dist['error']
    if gss4 != 'none': 
        gss4_grp = data.groupby([group_col1, group_col2])[actual, gss4].sum()
        gss4_dist = gss4_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss4_dist['error'] = abs(gss4_dist[actual]-gss4_dist[gss4])
        ttl_err_gss4 = gss4_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_gss4  = np.average(ttl_err_gss4['error'], weights = ttl_err_gss4[actual])
        err_dict["GSS 4"] = "{:.1%}".format(avg_err_gss4[0]/100)
        err_dict["GSS 4 (raw)"] = avg_err_gss4[0]/100
        df_dist['GSS_4_Dist'] = gss4_dist[gss4]
        df_dist['GSS_4_Err'] = gss4_dist['error']
    if gss5 != 'none': 
        gss5_grp = data.groupby([group_col1, group_col2])[actual, gss5].sum()
        gss5_dist = gss5_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss5_dist['error'] = abs(gss5_dist[actual]-gss5_dist[gss5])
        ttl_err_gss5 = gss5_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_gss5  = np.average(ttl_err_gss5['error'], weights = ttl_err_gss5[actual])
        err_dict["GSS 5"] = "{:.1%}".format(avg_err_gss5[0]/100)
        err_dict["GSS 5 (raw)"] = avg_err_gss5[0]/100
        df_dist['GSS_5_Dist'] = gss5_dist[gss5]
        df_dist['GSS_5_Err'] = gss5_dist['error']
    if gss6 != 'none': 
        gss6_grp = data.groupby([group_col1, group_col2])[actual, gss6].sum()
        gss6_dist = gss6_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss6_dist['error'] = abs(gss6_dist[actual]-gss6_dist[gss6])
        ttl_err_gss6 = gss6_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_gss6  = np.average(ttl_err_gss6['error'], weights = ttl_err_gss6[actual])
        err_dict["GSS 6"] = "{:.1%}".format(avg_err_gss6[0]/100)
        err_dict["GSS 6 (raw)"] = avg_err_gss6[0]/100
        df_dist['GSS_6_Dist'] = gss6_dist[gss6]
        df_dist['GSS_6_Err'] = gss6_dist['error']
    if gss7 != 'none': 
        gss7_grp = data.groupby([group_col1, group_col2])[actual, gss7].sum()
        gss7_dist = gss7_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss7_dist['error'] = abs(gss7_dist[actual]-gss7_dist[gss7])
        ttl_err_gss7 = gss7_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_gss7  = np.average(ttl_err_gss7['error'], weights = ttl_err_gss7[actual])
        err_dict["GSS 7"] = "{:.1%}".format(avg_err_gss7[0]/100)
        err_dict["GSS 7 (raw)"] = avg_err_gss7[0]/100
        df_dist['GSS_7_Dist'] = gss7_dist[gss7]
        df_dist['GSS_7_Err'] = gss7_dist['error']
    if gss8 != 'none': 
        gss8_grp = data.groupby([group_col1, group_col2])[actual, gss8].sum()
        gss8_dist = gss8_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss8_dist['error'] = abs(gss8_dist[actual]-gss8_dist[gss8])
        ttl_err_gss8 = gss8_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_gss8  = np.average(ttl_err_gss8['error'], weights = ttl_err_gss8[actual])
        err_dict["GSS 8"] = "{:.1%}".format(avg_err_gss8[0]/100)
        err_dict["GSS 8 (raw)"] = avg_err_gss8[0]/100
        df_dist['GSS_8_Dist'] = gss8_dist[gss8]
        df_dist['GSS_8_Err'] = gss8_dist['error']
    if gss9 != 'none': 
        gss9_grp = data.groupby([group_col1, group_col2])[actual, gss9].sum()
        gss9_dist = gss9_grp.groupby(level=0).apply(lambda x: round(x*100 / x.sum(),2))
        gss9_dist['error'] = abs(gss9_dist[actual]-gss9_dist[gss9])
        ttl_err_gss9 = gss9_dist.groupby(group_col1).agg({'error':'sum', actual:'sum'})
        avg_err_gss9  = np.average(ttl_err_gss9['error'], weights = ttl_err_gss9[actual])
        err_dict["GSS 9"] = "{:.1%}".format(avg_err_gss9[0]/100)
        err_dict["GSS 9 (raw)"] = avg_err_gss9[0]/100
        df_dist['GSS_9_Dist'] = gss9_dist[gss9]
        df_dist['GSS_9_Err'] = gss9_dist['error']
    return err_dict, df_dist.style


## https://git.soma.salesforce.com/Business-Data-Science/Quota-distribution-prediction/blob/master/Backtest%20Framework%20FY22.ipynb    
def dist_eval(lvls, pred,actual,data, pred2 = 'none', gss1 ='none', gss2 ='none',gss3 ='none',gss4 ='none',gss5 ='none',gss6 ='none',gss7 ='none', gss8 = 'none', gss9 = 'none'):
    """
dist_eval(lvls,'FY21_PRED_CORE', 'CORE_ACV_FY21',data, 'CORE_PRED_FY21_SHRAVAN', 'CORE_TTM_FY21','CORE_ACV_FY21_BLEND1','CORE_ACV_FY21_BLEND2','CORE_ACV_FY21_BLEND3','CORE_ACV_FY21_BLEND4','CORE_ACV_FY21_BLEND5','CORE_ACV_FY21_BLEND6')
    """
    errors = []
    for lvl, i in zip(lvls, range(0,len(lvls)-1)):
        errors.append(dist_error(lvl, lvls[i+1], pred,actual,data,pred2,gss1,gss2,gss3,gss4,gss5,gss6,gss7, gss8, gss9)[0])
    for err, lvl in zip(errors,lvls):
        print(lvl), print(err)
    return errors
  

def dist_error2(group_col1, group_col2, pred,actual, data, pred2 = 'none', gss1 = 'none', gss2 = 'none', gss3 = 'none', gss4 = 'none', gss5 = 'none', gss6 = 'none', gss7 = 'none'): 
    df_grouped = df_amer.groupby([group_col1, group_col2])[actual, pred].sum()
    df_dist =  df_grouped.groupby(level=0).apply(lambda x: x[actual].sum()*(x / x.sum()))
    df_dist['error'] = abs(df_dist[actual]-df_dist[pred])
    ttl_err = df_dist.groupby(group_col1).agg({'error':'sum'})
    avg_err = np.mean(ttl_err)
    err_dict = {"Pred 1": "${:10,}".format(round(avg_err[0],0))}
    err_dict["Pred 1 (raw)"] = round(avg_err[0],0)
    if pred2 != 'none':
        pred2_grp = data.groupby([group_col1, group_col2])[actual, pred2].sum()
        pred2_dist = pred2_grp.groupby(level=0).apply(lambda x: x[actual].sum()*(x / x.sum()))
        pred2_dist['error'] = abs(pred2_dist[actual]-pred2_dist[pred2])
        ttl_err_pred2 = pred2_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_pred2  = np.mean(ttl_err_pred2)
        err_dict["Pred 2"] = "${:10,}".format(round(avg_err[0],0))
        err_dict["Pred 2 (raw)"] = round(avg_err[0],0)
        df_dist['Pred_2_Dist'] = pred2_dist[pred2]
        df_dist['Pred_2_Err'] = pred2_dist['error']
    if gss1 != 'none': 
        gss1_grp = data.groupby([group_col1, group_col2])[actual, gss1].sum()
        gss1_dist = gss1_grp.groupby(level=0).apply(lambda x: x[actual].sum()*(x / x.sum()))
        gss1_dist['error'] = abs(gss1_dist[actual]-gss1_dist[gss1])
        ttl_err_gss1 = gss1_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss1  = np.mean(ttl_err_gss1)
        err_dict["GSS 1"] = "${:10,}".format(avg_err_gss1[0]/100)
        err_dict["GSS 1 (raw)"] = avg_err_gss1[0]/100
        df_dist['GSS_1_Dist'] = gss1_dist[gss1]
        df_dist['GSS_1_Err'] = gss1_dist['error']
    if gss2 != 'none': 
        gss2_grp = data.groupby([group_col1, group_col2])[actual, gss2].sum()
        gss2_dist = gss2_grp.groupby(level=0).apply(lambda x: x[actual].sum()*(x / x.sum()))
        gss2_dist['error'] = abs(gss2_dist[actual]-gss2_dist[gss2])
        ttl_err_gss2 = gss2_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss2  = np.mean(ttl_err_gss2)
        err_dict["GSS 2"] = "${:10,}".format(avg_err_gss2[0]/100)
        err_dict["GSS 2 (raw)"] = avg_err_gss2[0]/100
        df_dist['GSS_2_Dist'] = gss2_dist[gss2]
        df_dist['GSS_2_Err'] = gss2_dist['error']
    if gss3 != 'none': 
        gss3_grp = data.groupby([group_col1, group_col2])[actual, gss3].sum()
        gss3_dist = gss3_grp.groupby(level=0).apply(lambda x: x[actual].sum()*(x / x.sum()))
        gss3_dist['error'] = abs(gss3_dist[actual]-gss3_dist[gss3])
        ttl_err_gss3 = gss3_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss3  = np.mean(ttl_err_gss3)
        err_dict["GSS 3"] = "${:10,}".format(avg_err_gss3[0]/100)
        err_dict["GSS 3 (raw)"] = avg_err_gss3[0]/100
        df_dist['GSS_3_Dist'] = gss3_dist[gss3]
        df_dist['GSS_3_Err'] = gss3_dist['error']
    if gss4 != 'none': 
        gss4_grp = data.groupby([group_col1, group_col2])[actual, gss4].sum()
        gss4_dist = gss4_grp.groupby(level=0).apply(lambda x: x[actual].sum()*(x / x.sum()))
        gss4_dist['error'] = abs(gss4_dist[actual]-gss4_dist[gss4])
        ttl_err_gss4 = gss4_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss4  = np.mean(ttl_err_gss4)
        err_dict["GSS 4"] = "${:10,}".format(avg_err_gss4[0]/100)
        err_dict["GSS 4 (raw)"] = avg_err_gss4[0]/100
        df_dist['GSS_4_Dist'] = gss4_dist[gss4]
        df_dist['GSS_4_Err'] = gss4_dist['error']
    if gss5 != 'none': 
        gss5_grp = data.groupby([group_col1, group_col2])[actual, gss5].sum()
        gss5_dist = gss5_grp.groupby(level=0).apply(lambda x: x[actual].sum()*(x / x.sum()))
        gss5_dist['error'] = abs(gss5_dist[actual]-gss5_dist[gss5])
        ttl_err_gss5 = gss5_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss5  = np.mean(ttl_err_gss5)
        err_dict["GSS 5"] = "${:10,}".format(avg_err_gss5[0]/100)
        err_dict["GSS 5 (raw)"] = avg_err_gss5[0]/100
        df_dist['GSS_5_Dist'] = gss5_dist[gss5]
        df_dist['GSS_5_Err'] = gss5_dist['error']
    if gss6 != 'none': 
        gss6_grp = data.groupby([group_col1, group_col2])[actual, gss6].sum()
        gss6_dist = gss6_grp.groupby(level=0).apply(lambda x: x[actual].sum()*(x / x.sum()))
        gss6_dist['error'] = abs(gss6_dist[actual]-gss6_dist[gss6])
        ttl_err_gss6 = gss6_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss6  = np.mean(ttl_err_gss6)
        err_dict["GSS 6"] = "${:10,}".format(avg_err_gss6[0]/100)
        err_dict["GSS 6 (raw)"] = avg_err_gss6[0]/100
        df_dist['GSS_6_Dist'] = gss6_dist[gss6]
        df_dist['GSS_6_Err'] = gss6_dist['error']
    if gss7 != 'none': 
        gss7_grp = data.groupby([group_col1, group_col2])[actual, gss7].sum()
        gss7_dist = gss7_grp.groupby(level=0).apply(lambda x: x[actual].sum()*(x / x.sum()))
        gss7_dist['error'] = abs(gss7_dist[actual]-gss7_dist[gss7])
        ttl_err_gss7 = gss7_dist.groupby(group_col1).agg({'error':'sum'})
        avg_err_gss7  = np.mean(ttl_err_gss7)
        err_dict["GSS 7"] = "${:10,}".format(avg_err_gss7[0]/100)
        err_dict["GSS 7 (raw)"] = avg_err_gss7[0]/100
        df_dist['GSS_7_Dist'] = gss7_dist[gss7]
        df_dist['GSS_7_Err'] = gss7_dist['error']
    return err_dict, df_dist.style
  
    
def dist_eval_df(lvls, pred,actual,data, pred2 = 'none', gss1 ='none', gss2 ='none',gss3 ='none',gss4 ='none',gss5 ='none',gss6 ='none',gss7 ='none', ):
    errors = []
    for lvl, i in zip(lvls, range(0,len(lvls)-1)):
        errors.append(dist_error(lvl, lvls[i+1], pred,actual,data,pred2,gss1,gss2,gss3,gss4,gss5,gss6,gss7)[0])
    df = pd.DataFrame(errors, index=pd.Index(lvls[:-1], name='Level'))
    return df

    
def dist_group1_eval_df(grp1, lvls, dist_err_func,  pred,actual,data, pred2 = 'none', gss1 ='none', gss2 ='none',gss3 ='none',gss4 ='none',gss5 ='none',gss6 ='none',gss7 ='none', ):
    errors = []
    for lvl in lvls:
        errors.append(dist_err_func(grp1, lvl, pred,actual,data,pred2,gss1,gss2,gss3,gss4,gss5,gss6,gss7)[0])
    df = pd.DataFrame(errors, index=pd.Index(lvls, name='Level'))
    return df
# max_dist.dist_ou_wt_err(
#         grp1, grp2,  df.eval('best_predict_ = @pred'), f'CORE_ACV_FY{fy}', perf_eval_cols[f"FY{fy}"] + ['best_predict_'])

def scoring_model(data, metrics = ['FY21_CORE_AOV','CORE_TTM_FY21','FY21_CORE_OP', 'FY21_PRED_CORE'], weights = [.35, .25, .05, .25, .1], num_cust = 'COMBO_ID'):
    patch = data.groupby(['TERRITORY_NM','RVP_TERRITORY','LEAF_TERR_NAME'])[metrics].sum()
    patch['NUM_CUST'] = data.groupby(['TERRITORY_NM','RVP_TERRITORY','LEAF_TERR_NAME'])[num_cust].count()
    scoring = patch.groupby(level=0).apply(lambda x: x/x.mean())
    scoring['SCORE'] = scoring[metrics[0]]*weights[0] + scoring[metrics[1]]*weights[1] + scoring[metrics[2]]*weights[2] + scoring[metrics[3]]*weights[3] + scoring['NUM_CUST']*weights[4]
    scoring = scoring.groupby(level=1).apply(lambda x: round(x*100/x.sum(),2))
    return scoring 


def scoring_error(dist_error, actual, preds, scoring_model):
    merged_dist = dist_error[2].merge(scoring_model, on = ['RVP_TERRITORY','LEAF_TERR_NAME'])
    merged_dist['SCORING_ERR'] = abs(merged_dist[actual] - merged_dist['SCORE'])
    preds.append('SCORING_ERR')
    avg_scoring_err = merged_dist.groupby('RVP_TERRITORY')[preds].sum()
    errors = {}
    for pred in preds:
        errors[pred] = (np.mean(avg_scoring_err[pred]))
    return errors
