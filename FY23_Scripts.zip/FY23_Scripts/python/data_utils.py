'''
	ACV Prediction model based on GSI and Pricing models + trailing ACV. 
	
	Functions for running ETL and data cleanup.
	Initial version: 12/3/2021

'''
from datetime import datetime
from dateutil.relativedelta import relativedelta
import pandas as pd
import getpass
import json
import sys,os,logging
import warnings
warnings.filterwarnings("ignore")




def build_query_file(template_file,target_file,values_map):
	'''
	Converts template SQL files into runnable SQL

	Parameters:
		template_file - full name of template file
		target_file - full name of target file
		target_file - dictionary with find/replace pairs.  

	Return:
		Null

	'''
	with open(target_file, 'w') as fw:
		with open(template_file, 'r') as tr:
			for line in tr.readlines():
				for key in values_map.keys():
					line = line.replace(key,values_map[key])
				fw.write(line)




def build_t_minus_dates(start_date_str,date_format,num_years,add_TM0_date=False):
	'''
	Utility for building rolling dates based on a given start snap month. These values are used when building SQL files from the
	templates. 

	Parameters:
		start_date - The run-as snap month
		date_format - Date format used the SQL files
		num_years - Number of years to roll back
		add_TM0_date - Add a mapping for T minus 0 to T plus 1 years. (This is used for validation.) 

	Return:
		A dictionary with tag/date values.  

	'''
	date_templ_dir = {}
	if add_TM0_date == True:
		date_templ_dir[f'%T_P1Y'] = (datetime.strptime(start_date_str, date_format).date() + relativedelta(years= 1)).strftime(date_format)
		date_templ_dir[f'%OP_T_P1Y_OP1'] = (datetime.strptime(start_date_str, date_format).date() + relativedelta(years= 1,days=7)).strftime(date_format)
		date_templ_dir[f'%OP_T_P1Y_OP2'] = (datetime.strptime(start_date_str, date_format).date() + relativedelta(years= 1,days=6)).strftime(date_format)
	for t in range(num_years):
		date_templ_dir[f'%T_M{t}Y'] = (datetime.strptime(start_date_str, date_format).date() - relativedelta(years= t)).strftime(date_format)
		tmp_dt = datetime.strptime(start_date_str, date_format).date() - relativedelta(years= t)
		date_templ_dir[f'%OP_T_M{t}Y_OP1'] = (tmp_dt + relativedelta(days=7)).strftime(date_format)
		date_templ_dir[f'%OP_T_M{t}Y_OP2'] = (tmp_dt + relativedelta(days=6)).strftime(date_format)

	return date_templ_dir



def get_gsi_dates(values_map,df):
	'''
	Utility to figure out the dates for which we have a GSI model prediction. If we don't have a prediction for a given month, we try 
	to find the latest prediction month in the past. 

	Parameters:
		values_map - tag/date directory. (Typically built with  build_t_minus_dates())
		df - data frame with GSI model run dates. Column for run date shold be called "DATA_ASOF_DATE"

	Return:
		Directory with available GSI prediction dates. 

	'''
	df = df.sort_values(by='DATA_ASOF_DATE',ascending=True)
	gsi_snap_map = {}
	snap_counter = []
	for key in values_map.keys():
		if not key[0:3] == '%T_':
			continue

		snap_counter = snap_counter + [key]
		for index, row in df.iterrows():
		    dt = datetime.strptime(row['DATA_ASOF_DATE'][0:10], '%Y-%m-%d')
		    if dt < datetime.strptime(values_map[key], '%Y-%m-%d'):
		        gsi_snap_map[key] = (values_map[key],row['DATA_ASOF_DATE'][0:10])

	assert (len(set(snap_counter) - set(gsi_snap_map.keys())) == 0), "Cannot find GSI predictions for snaps:" + str(set(snap_counter) - set(gsi_snap_map.keys()))
	return gsi_snap_map



def check_and_create_dir(file_path):
	'''
	Utility for building a directory path, if the given path does not already exist.
	
	Parameters:
		file_path - requested path
	Return:
		Null

	'''
	if not os.path.exists(file_path):
		try:
			os.makedirs(file_path)
		except:
			return




def main():
	if len(sys.argv) < 1:
		print ('usage: python data_utils.py "snap_list"')
		return

	logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s',level=logging.INFO)
	snap_month_input = sys.argv[1]
	logging.info('snap_month_input: '+snap_month_input)

	snap_months = snap_month_input.split('|')
	logging.info('Running snaps: '+str(snap_months))

	for snap_month in snap_months:
		logging.info('Starting snap: '+snap_month)


	    # Set run params
		cmap = json.loads(open('run_config.json').read())
		date_format = "%Y-%m-%d"
		t_m0_date = snap_month
		snap_dir = t_m0_date.replace('-','') + '/'
		values_map = build_t_minus_dates(t_m0_date,date_format,8,add_TM0_date=True)

		user_name = getpass.getuser()
		smds_lib_path = cmap['smds_lib_path'].replace('%user_name', user_name)
		ai4g_home = cmap['ai4g_home'].replace('%user_name', user_name)
		cred_file_path = cmap['cred_file_path'].replace('%user_name', user_name)
		snap_dir_path = ai4g_home + cmap['data_home'] + cmap['dump_dir'] + snap_dir 
		sql_dir_path = ai4g_home + cmap['data_home'] + cmap['sql_dir'] + snap_dir 
		template_dir_path  = ai4g_home + cmap['code_home'] + cmap['template_dir']
		flg_run_queries = False
		if cmap['run_queries'] == 'true':
			flg_run_queries = True
		logging.info('Run queries: '+str(flg_run_queries))

		flg_get_gsi_dates = False
		if cmap['get_gsi_dates'] == 'true':
			flg_get_gsi_dates = True
		logging.info('Get GSI dates: '+str(flg_get_gsi_dates))

		flg_check_acv_load_status = False
		if cmap['check_acv_status'] == 'true':
			flg_check_acv_load_status = True
		logging.info('Check ACV load status: '+str(flg_check_acv_load_status))



		# Create data directories
		check_and_create_dir(snap_dir_path)
		check_and_create_dir(sql_dir_path)



		# Check ACV table load status
		srcfile = template_dir_path + cmap['check_acv_query']
		tgtfile = sql_dir_path + cmap['check_acv_query']
		build_query_file(srcfile,tgtfile,values_map)


		if flg_check_acv_load_status == True:
			check_query = tgtfile
			sys.path.append(smds_lib_path)
			import db_etl as etl
			db_connection = etl.DB_ETL(cred_file_path)
			cursor = db_connection.oracle_connection()
			db_connection.run_sql_to_disk(cursor, check_query, snap_dir_path+'check_acv.csv', True, ',',print_debug=True)
			cursor.close()
			logging.info('Stored ACV load status into '+snap_dir_path+'check_acv.csv')
			df_test = pd.read_csv(snap_dir_path+'check_acv.csv')
			if df_test.iloc[0].STATUS == 'OK':
				logging.info('ACV load status = OK.')
			else:
				assert False,'Bad ACV load status! ACV table not loaded for today.'

		
		


		#Figure out dates for GSI predictions
		srcfile = template_dir_path + 'get_gsi_pred_dates.sql'
		tgtfile = sql_dir_path + 'get_gsi_pred_dates.sql'
		build_query_file(srcfile,tgtfile,values_map)

		if flg_get_gsi_dates == True:
			gsi_query = tgtfile
			sys.path.append(smds_lib_path)
			import db_etl as etl
			db_connection = etl.DB_ETL(cred_file_path)
			cursor = db_connection.oracle_connection()
			db_connection.run_sql_to_disk(cursor, gsi_query, snap_dir_path+'gsi_snaps.csv', True, ',',print_debug=True)
			cursor.close()
			logging.info('Loaded GSI snaps into '+snap_dir_path+'gsi_snaps.csv')
		else:
			logging.warning('Not loading GSI snaps!')



		# Build GSI dates 
		gsi_values_map = build_t_minus_dates(t_m0_date,date_format,4)
		df_gsi_snaps = pd.read_csv(snap_dir_path + 'gsi_snaps.csv') 
		gsi_dates_map = get_gsi_dates(gsi_values_map,df_gsi_snaps)
		cntr = 0
		for key in gsi_dates_map.keys():
			values_map['%GSI_SNAP_YM'+str(cntr)] = gsi_dates_map[key][1]
			cntr = cntr + 1


		srcfile = template_dir_path + 'train_data_template.sql'
		tfile_train_query = sql_dir_path + 'train_data.sql'
		build_query_file(srcfile,tfile_train_query,values_map)
		logging.info('Query file built as: '+tfile_train_query)


		if flg_run_queries == True:
			sys.path.append(smds_lib_path)
			import db_etl as etl
			db_connection = etl.DB_ETL(cred_file_path)
			cursor = db_connection.oracle_connection()
			db_connection.run_sql_to_disk(cursor, tfile_train_query, snap_dir_path+'aig4g_train_data_'+t_m0_date+ '.csv', True, ',',print_debug=True)
			cursor.close()

		logging.info('Done with snap '+snap_month+'.')

if __name__ == '__main__':
    main()







