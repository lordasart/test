import numpy as np
import pandas as pd


EPSILON = 1e-10


def _error(actual: np.ndarray, predicted: np.ndarray):
    """ Simple error """
    return actual - predicted


# def meanape(actual: np.ndarray, predicted: np.ndarray, cut=0.01):
#     y_true, y_pred = np.array(actual), np.array(predicted)
#     result = np.array(sorted(np.abs((y_true - y_pred) / y_true), reverse=True))[int(len(y_true) * cut):]
#     return np.mean(result) * 100


def _percentage_error(actual: np.ndarray, predicted: np.ndarray):
    """
    Percentage error
    Note: result is NOT multiplied by 100
    """
    return _error(actual, predicted) / (actual + EPSILON)




def pct_diff_over_20pct(actual: np.ndarray, predicted: np.ndarray):
    return round(np.mean(_percentage_error(actual,predicted))/1000,2)


def rss(y_true, y_pred):
    return np.sum((y_true - y_pred)**2)


def mse(actual: np.ndarray, predicted: np.ndarray):
    """ Mean Squared Error """
    return np.mean(np.square(_error(actual, predicted)))


def rmse(actual: np.ndarray, predicted: np.ndarray):
    """ Root Mean Squared Error """
    return np.sqrt(mse(actual, predicted))


def mae(actual: np.ndarray, predicted: np.ndarray):
    """ Mean Absolute Error """
    return np.mean(np.abs(_error(actual, predicted)))


def mdae(actual: np.ndarray, predicted: np.ndarray):
    """ Median Absolute Error """
    return np.median(np.abs(_error(actual, predicted)))


def mpe(actual: np.ndarray, predicted: np.ndarray):
    """ Mean Percentage Error """
    return np.mean(_percentage_error(actual, predicted))


def mape(actual: np.ndarray, predicted: np.ndarray):
    """
    Mean Absolute Percentage Error
    Properties:
        + Easy to interpret
        + Scale independent
        - Biased, not symmetric
        - Undefined when actual[t] == 0
    Note: result is NOT multiplied by 100
    """
    return np.mean(np.abs(_percentage_error(actual, predicted)))


def mdape(actual: np.ndarray, predicted: np.ndarray):
    """
    Median Absolute Percentage Error
    Note: result is NOT multiplied by 100
    """
    return np.median(np.abs(_percentage_error(actual, predicted)))


def rmspe(actual: np.ndarray, predicted: np.ndarray):
    """
    Root Mean Squared Percentage Error
    Note: result is NOT multiplied by 100
    """
    return np.sqrt(np.mean(np.square(_percentage_error(actual, predicted))))


def rmdspe(actual: np.ndarray, predicted: np.ndarray):
    """
    Root Median Squared Percentage Error
    Note: result is NOT multiplied by 100
    """
    return np.sqrt(np.median(np.square(_percentage_error(actual, predicted))))


def rmsle(actual: np.ndarray, predicted: np.ndarray):
    """
    Root Median Squared Log Error
    """
    # return np.sqrt(mean_squared_log_error(actual, predicted))
    return np.sqrt(np.mean((np.log(1+predicted) - np.log(1+actual))**2))


METRICS = {
    'mae': mae,
    'mdae': mdae,
    'mse': mse,
    'rmse': rmse,
    'mape': mape,
    'mdape': mdape,
    'rmsle': rmsle,
    'rss':rss
}


eval_metrics = ('mae', 'mdae', 'mse', 'rmse', 'mdape','mape' ,'rmsle')


def evaluate(actual: np.ndarray, predicted: np.ndarray, metrics=eval_metrics):
    results = {}
    for name in metrics:
        try:
            results[name] = METRICS[name](actual, predicted)
        except Exception as err:
            results[name] = np.nan
            print('Unable to compute metric {0}: {1}'.format(name, err))
    return results
