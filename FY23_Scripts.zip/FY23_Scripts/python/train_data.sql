BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE AIG4G_ACCT_ACV_FY';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@


CREATE TABLE AIG4G_ACCT_ACV_FY AS
SELECT /*+PARALLEL(16)*/
	'T_M0Y' PERIOD,
    DATE '2019-11-01' START_DATE,
    DATE '2020-11-01' END_DATE,
  	acct_id,
	        sum(CASE WHEN DRVD_CLOUD_PRNT_NM = 'Marketing' AND PXE_CLOUD_LVL_2_NM != 'Pardot' THEN ACV_PLAN_FX ELSE 0 end) MC_ACV,
        sum(CASE WHEN PXE_CLOUD_LVL_2_NM = 'B2C Commerce' THEN ACV_PLAN_FX ELSE 0 end) CC_ACV,
        sum(CASE WHEN (DRVD_CLOUD_PRNT_NM NOT IN ('Commerce', 'Marketing')) OR PXE_CLOUD_LVL_2_NM in ('Pardot', 'B2B Commerce') THEN ACV_PLAN_FX ELSE 0 end) CORE_ACV,
        sum(acv_plan_fx) total_acv
    FROM dm.fact_acv
    WHERE
        OPTY_CLSD_DT between DATE '2019-11-01' AND DATE '2020-11-01'
        AND directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND PXE_CLOUD_LVL_2_NM NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM')
    GROUP BY 'T_M1Y',DATE '2019-11-01', DATE '2020-11-01',ACCT_ID
UNION ALL
SELECT /*+PARALLEL(16)*/
	'T_M1Y' PERIOD,
    DATE '2018-11-01' START_DATE,
    DATE '2019-11-01' END_DATE,
  	acct_id,
	        sum(CASE WHEN DRVD_CLOUD_PRNT_NM = 'Marketing' AND PXE_CLOUD_LVL_2_NM != 'Pardot' THEN ACV_PLAN_FX ELSE 0 end) MC_ACV,
        sum(CASE WHEN PXE_CLOUD_LVL_2_NM = 'B2C Commerce' THEN ACV_PLAN_FX ELSE 0 end) CC_ACV,
        sum(CASE WHEN (DRVD_CLOUD_PRNT_NM NOT IN ('Commerce', 'Marketing')) OR PXE_CLOUD_LVL_2_NM in ('Pardot', 'B2B Commerce') THEN ACV_PLAN_FX ELSE 0 end) CORE_ACV,
        sum(acv_plan_fx) total_acv
    FROM dm.fact_acv
    WHERE
        OPTY_CLSD_DT between DATE '2018-11-01' AND DATE '2019-11-01'
        AND directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND PXE_CLOUD_LVL_2_NM NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM')
    GROUP BY 'T_M1Y',DATE '2018-11-01', DATE '2019-11-01',ACCT_ID
UNION ALL
SELECT
	'T_M2Y' PERIOD,
    DATE '2017-11-01' START_DATE,
    DATE '2018-11-01' END_DATE,
  	acct_id,
	        sum(CASE WHEN DRVD_CLOUD_PRNT_NM = 'Marketing' AND PXE_CLOUD_LVL_2_NM != 'Pardot' THEN ACV_PLAN_FX ELSE 0 end) MC_ACV,
        sum(CASE WHEN PXE_CLOUD_LVL_2_NM = 'B2C Commerce' THEN ACV_PLAN_FX ELSE 0 end) CC_ACV,
        sum(CASE WHEN (DRVD_CLOUD_PRNT_NM NOT IN ('Commerce', 'Marketing')) OR PXE_CLOUD_LVL_2_NM in ('Pardot', 'B2B Commerce') THEN ACV_PLAN_FX ELSE 0 end) CORE_ACV,
        sum(acv_plan_fx) total_acv
    FROM dm.fact_acv
    WHERE
        OPTY_CLSD_DT between DATE '2017-11-01' AND DATE '2018-11-01'
        AND directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND PXE_CLOUD_LVL_2_NM NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM')
    GROUP BY 'T_M2Y',DATE '2017-11-01', DATE '2018-11-01',ACCT_ID
UNION ALL
SELECT
	'T_M3Y' PERIOD,
    DATE '2016-11-01' START_DATE,
    DATE '2017-11-01' END_DATE,
  	acct_id,
	        sum(CASE WHEN DRVD_CLOUD_PRNT_NM = 'Marketing' AND PXE_CLOUD_LVL_2_NM != 'Pardot' THEN ACV_PLAN_FX ELSE 0 end) MC_ACV,
        sum(CASE WHEN PXE_CLOUD_LVL_2_NM = 'B2C Commerce' THEN ACV_PLAN_FX ELSE 0 end) CC_ACV,
        sum(CASE WHEN (DRVD_CLOUD_PRNT_NM NOT IN ('Commerce', 'Marketing')) OR PXE_CLOUD_LVL_2_NM in ('Pardot', 'B2B Commerce') THEN ACV_PLAN_FX ELSE 0 end) CORE_ACV,
        sum(acv_plan_fx) total_acv
    FROM dm.fact_acv
    WHERE
        OPTY_CLSD_DT between DATE '2016-11-01' AND DATE '2017-11-01'
        AND directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND PXE_CLOUD_LVL_2_NM NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM')
    GROUP BY 'T_M3Y',DATE '2016-11-01', DATE '2017-11-01',ACCT_ID
    UNION ALL
SELECT
	'T_M4Y' PERIOD,
    DATE '2015-11-01' START_DATE,
    DATE '2016-11-01' END_DATE,
  	acct_id,
	        sum(CASE WHEN DRVD_CLOUD_PRNT_NM = 'Marketing' AND PXE_CLOUD_LVL_2_NM != 'Pardot' THEN ACV_PLAN_FX ELSE 0 end) MC_ACV,
        sum(CASE WHEN PXE_CLOUD_LVL_2_NM = 'B2C Commerce' THEN ACV_PLAN_FX ELSE 0 end) CC_ACV,
        sum(CASE WHEN (DRVD_CLOUD_PRNT_NM NOT IN ('Commerce', 'Marketing')) OR PXE_CLOUD_LVL_2_NM in ('Pardot', 'B2B Commerce') THEN ACV_PLAN_FX ELSE 0 end) CORE_ACV,
        sum(acv_plan_fx) total_acv
    FROM dm.fact_acv
    WHERE
        OPTY_CLSD_DT between DATE '2015-11-01' AND DATE '2016-11-01'
        AND directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND PXE_CLOUD_LVL_2_NM NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM')
    GROUP BY 'T_M4Y',DATE '2015-11-01', DATE '2016-11-01',ACCT_ID
    UNION ALL
SELECT
	'T_M5Y' PERIOD,
    DATE '2014-11-01' START_DATE,
    DATE '2015-11-01' END_DATE,
  	acct_id,
	        sum(CASE WHEN DRVD_CLOUD_PRNT_NM = 'Marketing' AND PXE_CLOUD_LVL_2_NM != 'Pardot' THEN ACV_PLAN_FX ELSE 0 end) MC_ACV,
        sum(CASE WHEN PXE_CLOUD_LVL_2_NM = 'B2C Commerce' THEN ACV_PLAN_FX ELSE 0 end) CC_ACV,
        sum(CASE WHEN (DRVD_CLOUD_PRNT_NM NOT IN ('Commerce', 'Marketing')) OR PXE_CLOUD_LVL_2_NM in ('Pardot', 'B2B Commerce') THEN ACV_PLAN_FX ELSE 0 end) CORE_ACV,
        sum(acv_plan_fx) total_acv
    FROM dm.fact_acv
    WHERE
        OPTY_CLSD_DT between DATE '2014-11-01' AND DATE '2015-11-01'
        AND directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND PXE_CLOUD_LVL_2_NM NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM')
    GROUP BY 'T_M5Y',DATE '2014-11-01', DATE '2015-11-01',ACCT_ID
    UNION ALL
SELECT
	'T_M6Y' PERIOD,
    DATE '2013-11-01' START_DATE,
    DATE '2014-11-01' END_DATE,
  	acct_id,
	        sum(CASE WHEN DRVD_CLOUD_PRNT_NM = 'Marketing' AND PXE_CLOUD_LVL_2_NM != 'Pardot' THEN ACV_PLAN_FX ELSE 0 end) MC_ACV,
        sum(CASE WHEN PXE_CLOUD_LVL_2_NM = 'B2C Commerce' THEN ACV_PLAN_FX ELSE 0 end) CC_ACV,
        sum(CASE WHEN (DRVD_CLOUD_PRNT_NM NOT IN ('Commerce', 'Marketing')) OR PXE_CLOUD_LVL_2_NM in ('Pardot', 'B2B Commerce') THEN ACV_PLAN_FX ELSE 0 end) CORE_ACV,
        sum(acv_plan_fx) total_acv
    FROM dm.fact_acv
    WHERE
        OPTY_CLSD_DT between DATE '2013-11-01' AND DATE '2014-11-01'
        AND directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND PXE_CLOUD_LVL_2_NM NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM')
    GROUP BY 'T_M6Y',DATE '2013-11-01', DATE '2014-11-01',ACCT_ID
    UNION ALL
SELECT
	'T_M7Y' PERIOD,
    DATE '2012-11-01' START_DATE,
    DATE '2013-11-01' END_DATE,
  	acct_id,
	        sum(CASE WHEN DRVD_CLOUD_PRNT_NM = 'Marketing' AND PXE_CLOUD_LVL_2_NM != 'Pardot' THEN ACV_PLAN_FX ELSE 0 end) MC_ACV,
        sum(CASE WHEN PXE_CLOUD_LVL_2_NM = 'B2C Commerce' THEN ACV_PLAN_FX ELSE 0 end) CC_ACV,
        sum(CASE WHEN (DRVD_CLOUD_PRNT_NM NOT IN ('Commerce', 'Marketing')) OR PXE_CLOUD_LVL_2_NM in ('Pardot', 'B2B Commerce') THEN ACV_PLAN_FX ELSE 0 end) CORE_ACV,
        sum(acv_plan_fx) total_acv
    FROM dm.fact_acv
    WHERE
        OPTY_CLSD_DT between DATE '2012-11-01' AND DATE '2013-11-01'
        AND directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND PXE_CLOUD_LVL_2_NM NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM')
    GROUP BY 'T_M7Y',DATE '2012-11-01', DATE '2013-11-01',ACCT_ID
   UNION ALL
	SELECT
	'FY21' PERIOD,
 	DATE '2020-02-01' START_DATE,
    DATE '2021-02-01' END_DATE,
    acct_id,
        sum(CASE WHEN DRVD_CLOUD_PRNT_NM = 'Marketing' AND PXE_CLOUD_LVL_2_NM != 'Pardot' THEN ACV_PLAN_FX ELSE 0 end) MC_ACV,
        sum(CASE WHEN PXE_CLOUD_LVL_2_NM = 'B2C Commerce' THEN ACV_PLAN_FX ELSE 0 end) CC_ACV,
        sum(CASE WHEN (DRVD_CLOUD_PRNT_NM NOT IN ('Commerce', 'Marketing')) OR PXE_CLOUD_LVL_2_NM in ('Pardot', 'B2B Commerce') THEN ACV_PLAN_FX ELSE 0 end) CORE_ACV,
        sum(acv_plan_fx) total_acv
    FROM dm.fact_acv 
    WHERE 
        fiscal_yr_num  = 2021
        AND directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND PXE_CLOUD_LVL_2_NM NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM') 
    GROUP BY 'FY21',DATE '2020-02-01',DATE '2021-02-01',ACCT_ID

@





BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE AIG4G_aov_backtest_fy';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@

	

CREATE TABLE AIG4G_aov_backtest_fy AS (
SELECT /*+PARALLEL(16)*/
   acct_id, 
	sum(CASE WHEN DT_KEY = DATE '2019-11-01' THEN ALLOC_AOV ELSE 0 END) T_M0Y_AOV,
	sum(CASE WHEN DT_KEY = DATE '2019-11-01' AND (drvd_prod_lvl_1 NOT IN ('Marketing','Commerce') OR DRVD_PROD_LVL_2 IN ('Pardot', 'B2B Commerce')) THEN ALLOC_AOV ELSE 0 END) T_M0Y_core_aov,
	sum(CASE WHEN DT_KEY = DATE '2019-11-01' AND (drvd_prod_lvl_1= 'Marketing' AND DRVD_PROD_LVL_2 != 'Pardot') THEN ALLOC_AOV ELSE 0 END) T_M0Y_mc_aov,
	sum(CASE WHEN DT_KEY = DATE '2019-11-01' AND (drvd_prod_lvl_1= 'Commerce' AND DRVD_PROD_LVL_2 != 'B2B Commerce') THEN ALLOC_AOV ELSE 0 END) T_M0Y_cc_aov,
	sum(CASE WHEN DT_KEY = DATE '2018-11-01' THEN ALLOC_AOV ELSE 0 END) T_M1Y_aov,
	sum(CASE WHEN DT_KEY = DATE '2018-11-01' AND (drvd_prod_lvl_1 NOT IN ('Marketing','Commerce') OR DRVD_PROD_LVL_2 IN ('Pardot', 'B2B Commerce')) THEN ALLOC_AOV ELSE 0 END) T_M1Y_core_aov,
	sum(CASE WHEN DT_KEY = DATE '2018-11-01' AND (drvd_prod_lvl_1= 'Marketing' AND DRVD_PROD_LVL_2 != 'Pardot') THEN ALLOC_AOV ELSE 0 END) T_M1Y_mc_aov,
	sum(CASE WHEN DT_KEY = DATE '2018-11-01' AND (drvd_prod_lvl_1= 'Commerce' AND DRVD_PROD_LVL_2 != 'B2B Commerce') THEN ALLOC_AOV ELSE 0 END) T_M1Y_cc_aov,
	sum(CASE WHEN DT_KEY = DATE '2017-11-01' THEN ALLOC_AOV ELSE 0 END) T_M2Y_aov, 
	sum(CASE WHEN DT_KEY = DATE '2017-11-01' AND (drvd_prod_lvl_1 NOT IN ('Marketing','Commerce') OR DRVD_PROD_LVL_2 IN ('Pardot', 'B2B Commerce')) THEN ALLOC_AOV ELSE 0 END) T_M2Y_core_aov,
	sum(CASE WHEN DT_KEY = DATE '2017-11-01' AND (drvd_prod_lvl_1= 'Marketing' AND DRVD_PROD_LVL_2 != 'Pardot') THEN ALLOC_AOV ELSE 0 END) T_M2Y_mc_aov,
	sum(CASE WHEN DT_KEY = DATE '2017-11-01' AND (drvd_prod_lvl_1= 'Commerce' AND DRVD_PROD_LVL_2 != 'B2B Commerce') THEN ALLOC_AOV ELSE 0 END) T_M2Y_cc_aov,
	sum(CASE WHEN DT_KEY = DATE '2016-11-01' THEN ALLOC_AOV ELSE 0 END) T_M3Y_aov, 
	sum(CASE WHEN DT_KEY = DATE '2016-11-01' AND (drvd_prod_lvl_1 NOT IN ('Marketing','Commerce') OR DRVD_PROD_LVL_2 IN ('Pardot', 'B2B Commerce')) THEN ALLOC_AOV ELSE 0 END) T_M3Y_core_aov,
	sum(CASE WHEN DT_KEY = DATE '2016-11-01' AND (drvd_prod_lvl_1= 'Marketing' AND DRVD_PROD_LVL_2 != 'Pardot') THEN ALLOC_AOV ELSE 0 END) T_M3Y_mc_aov,
	sum(CASE WHEN DT_KEY = DATE '2016-11-01' AND (drvd_prod_lvl_1= 'Commerce' AND DRVD_PROD_LVL_2 != 'B2B Commerce') THEN ALLOC_AOV ELSE 0 END) T_M3Y_cc_aov,
	sum(CASE WHEN DT_KEY = DATE '2015-11-01' THEN ALLOC_AOV ELSE 0 END) T_M4Y_aov,
	sum(CASE WHEN DT_KEY = DATE '2015-11-01' AND (drvd_prod_lvl_1 NOT IN ('Marketing','Commerce') OR DRVD_PROD_LVL_2 IN ('Pardot', 'B2B Commerce')) THEN ALLOC_AOV ELSE 0 END) T_M4Y_core_aov,
	sum(CASE WHEN DT_KEY = DATE '2015-11-01' AND (drvd_prod_lvl_1= 'Marketing' AND DRVD_PROD_LVL_2 != 'Pardot') THEN ALLOC_AOV ELSE 0 END) T_M4Y_mc_aov,
	sum(CASE WHEN DT_KEY = DATE '2015-11-01' AND (drvd_prod_lvl_1= 'Commerce' AND DRVD_PROD_LVL_2 != 'B2B Commerce') THEN ALLOC_AOV ELSE 0 END) T_M4Y_cc_aov
FROM dm.FACT_AOV_SS 
WHERE directs NOT IN ('Terry Tripp', 'Dan Miller', 'Greg Tarantino') AND DRVD_PROD_LVL_2 NOT IN ('Vlocity - Sales', 'Vlocity - Service', 'Tableau CRM') 
GROUP BY acct_id )
@



BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE AIG4G_ftm_op_fy';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@


CREATE TABLE AIG4G_ftm_op_fy AS (
SELECT /*+PARALLEL(16)*/
	acct_id, 
	sum(CASE WHEN snap_date = DATE '2015-11-08' AND CLSD_DT <= DATE '2016-11-07' THEN OPTY_AMT ELSE 0 END) T_M4Y_op,
	sum(CASE WHEN snap_date = DATE '2015-11-08' AND CLSD_DT <= DATE '2016-11-07' AND APM_LEVEL_1 NOT IN ('Marketing', 'Commerce') THEN OPTY_AMT ELSE 0 END) T_M4Y_core_op,
	sum(CASE WHEN snap_date = DATE '2015-11-08' AND CLSD_DT <= DATE '2016-11-07' AND APM_LEVEL_1 = 'Marketing' THEN OPTY_AMT ELSE 0 END) T_M4Y_mc_op,
	sum(CASE WHEN snap_date = DATE '2015-11-08' AND CLSD_DT <= DATE '2016-11-07' AND APM_LEVEL_1 = 'Commerce' THEN OPTY_AMT ELSE 0 END) T_M4Y_cc_op,
	sum(CASE WHEN snap_date = DATE '2016-11-08' AND CLSD_DT <= DATE '2017-11-07' THEN OPTY_AMT ELSE 0 END) T_M3Y_op,
	sum(CASE WHEN snap_date = DATE '2016-11-08' AND CLSD_DT <= DATE '2017-11-07' AND APM_LEVEL_1 NOT IN ('Marketing', 'Commerce') THEN OPTY_AMT ELSE 0 END) T_M3Y_core_op,
	sum(CASE WHEN snap_date = DATE '2016-11-08' AND CLSD_DT <= DATE '2017-11-07' AND APM_LEVEL_1 = 'Marketing' THEN OPTY_AMT ELSE 0 END) T_M3Y_mc_op,
	sum(CASE WHEN snap_date = DATE '2016-11-08' AND CLSD_DT <= DATE '2017-11-07' AND APM_LEVEL_1 = 'Commerce' THEN OPTY_AMT ELSE 0 END) T_M3Y_cc_op,
	sum(CASE WHEN snap_date = DATE '2017-11-08' AND CLSD_DT <= DATE '2018-11-07' THEN OPTY_AMT ELSE 0 END) T_M2Y_op,
	sum(CASE WHEN snap_date = DATE '2017-11-08' AND CLSD_DT <= DATE '2018-11-07' AND APM_LEVEL_1 NOT IN ('Marketing', 'Commerce') THEN OPTY_AMT ELSE 0 END) T_M2Y_core_op,
	sum(CASE WHEN snap_date = DATE '2017-11-08' AND CLSD_DT <= DATE '2018-11-07' AND APM_LEVEL_1 = 'Marketing' THEN OPTY_AMT ELSE 0 END) T_M2Y_mc_op,
	sum(CASE WHEN snap_date = DATE '2017-11-08' AND CLSD_DT <= DATE '2018-11-07' AND APM_LEVEL_1 = 'Commerce' THEN OPTY_AMT ELSE 0 END) T_M2Y_cc_op,
	sum(CASE WHEN snap_date = DATE '2018-11-08' AND CLSD_DT <= DATE '2019-11-07' THEN OPTY_AMT ELSE 0 END) T_M1Y_op,
	sum(CASE WHEN snap_date = DATE '2018-11-08' AND CLSD_DT <= DATE '2019-11-07' AND APM_LEVEL_1 NOT IN ('Marketing', 'Commerce') THEN OPTY_AMT ELSE 0 END) T_M1Y_core_op, 
	sum(CASE WHEN snap_date = DATE '2018-11-08' AND CLSD_DT <= DATE '2019-11-07' AND APM_LEVEL_1 = 'Marketing' THEN OPTY_AMT ELSE 0 END) T_M1Y_mc_op, 
	sum(CASE WHEN snap_date = DATE '2018-11-08' AND CLSD_DT <= DATE '2019-11-07' AND APM_LEVEL_1 = 'Commerce' THEN OPTY_AMT ELSE 0 END) T_M1Y_cc_op,
	sum(CASE WHEN snap_date = DATE '2019-11-08' AND CLSD_DT <= DATE '2020-11-07' THEN OPTY_AMT ELSE 0 END) T_M0Y_op,
	sum(CASE WHEN snap_date = DATE '2019-11-08' AND CLSD_DT <= DATE '2020-11-07' AND APM_LEVEL_1 NOT IN ('Marketing', 'Commerce') THEN OPTY_AMT ELSE 0 END) T_M0Y_core_op, 
	sum(CASE WHEN snap_date = DATE '2019-11-08' AND CLSD_DT <= DATE '2020-11-07' AND APM_LEVEL_1 = 'Marketing' THEN OPTY_AMT ELSE 0 END) T_M0Y_mc_op, 
	sum(CASE WHEN snap_date = DATE '2019-11-08' AND CLSD_DT <= DATE '2020-11-07' AND APM_LEVEL_1 = 'Commerce' THEN OPTY_AMT ELSE 0 END) T_M0Y_cc_op
FROM gpsa.pipe_quality_weekly 
WHERE OPTY_RANK = 1 AND directs NOT IN ('Terry Tripp','Dan Miller', 'Greg Tarantino')
	AND OPTY_IND = 'OPENPIPE' AND APM_LEVEL_1 != 'Analytics' AND 
	OPTY_AMT < 30000000 AND OPTY_AMT > -30000000
GROUP BY acct_id 
) @
 

    

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE AIG4G_ACCT_ACV_PRED_FY';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@

CREATE TABLE AIG4G_ACCT_ACV_PRED_FY AS
SELECT /*+PARALLEL(16)*/ a.*, 'T_M0Y' PERIOD FROM BDS_OPS.UF_ACCT_ACV_MONTHLY a WHERE DATA_ASOF_DATE = DATE '2019-10-01'
UNION 
SELECT a.*, 'T_M1Y' PERIOD  FROM BDS_OPS.UF_ACCT_ACV_MONTHLY a WHERE DATA_ASOF_DATE = DATE '2018-01-01'
UNION
SELECT a.*, 'T_M2Y' PERIOD FROM BDS_OPS.UF_ACCT_ACV_MONTHLY a WHERE DATA_ASOF_DATE = DATE '2017-10-01'
UNION
SELECT a.*, 'T_M3Y' PERIOD FROM BDS_OPS.UF_ACCT_ACV_MONTHLY a WHERE DATA_ASOF_DATE = DATE '2016-10-01'
@




BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE AIG4G_ACV_BACKTEST_FY';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@

CREATE TABLE AIG4G_ACV_BACKTEST_FY AS 
SELECT /*+PARALLEL(16)*/
	nvl(a.acct_id_acv, b.acct_id_pred) acct_id ,
	nvl(a.total_acv_T_M0Y, 0) total_acv_T_M0Y, 
	nvl(a.core_acv_T_M0Y, 0) core_acv_T_M0Y, 
	nvl(a.mc_acv_T_M0Y, 0) mc_acv_T_M0Y, 
	nvl(a.cc_acv_T_M0Y, 0) cc_acv_T_M0Y,
	nvl(a.total_acv_T_M1Y, 0) total_acv_T_M1Y, 
	nvl(a.core_acv_T_M1Y, 0) core_acv_T_M1Y, 
	nvl(a.mc_acv_T_M1Y, 0) mc_acv_T_M1Y, 
	nvl(a.cc_acv_T_M1Y, 0) cc_acv_T_M1Y,
	nvl(a.total_acv_T_M2Y, 0) total_acv_T_M2Y, 
	nvl(a.core_acv_T_M2Y, 0) core_acv_T_M2Y, 
	nvl(a.mc_acv_T_M2Y, 0) mc_acv_T_M2Y, 
	nvl(a.cc_acv_T_M2Y, 0) cc_acv_T_M2Y, 
	nvl(a.total_acv_T_M3Y, 0) total_acv_T_M3Y, 
	nvl(a.core_acv_T_M3Y, 0) core_acv_T_M3Y, 
	nvl(a.mc_acv_T_M3Y, 0) mc_acv_T_M3Y, 
	nvl(a.cc_acv_T_M3Y, 0) cc_acv_T_M3Y,
	nvl(a.total_acv_T_M4Y, 0) total_acv_T_M4Y, 
	nvl(a.core_acv_T_M4Y, 0) core_acv_T_M4Y, 
	nvl(a.mc_acv_T_M4Y, 0) mc_acv_T_M4Y, 
	nvl(a.cc_acv_T_M4Y, 0) cc_acv_T_M4Y,
	nvl(a.total_acv_T_M5Y, 0) total_acv_T_M5Y, 
	nvl(a.core_acv_T_M5Y, 0) core_acv_T_M5Y, 
	nvl(a.mc_acv_T_M5Y, 0) mc_acv_T_M5Y, 
	nvl(a.cc_acv_T_M5Y, 0) cc_acv_T_M5Y,
	nvl(a.total_acv_T_M6Y, 0) total_acv_T_M6Y, 
	nvl(a.core_acv_T_M6Y, 0) core_acv_T_M6Y, 
	nvl(a.mc_acv_T_M6Y, 0) mc_acv_T_M6Y, 
	nvl(a.cc_acv_T_M6Y, 0) cc_acv_T_M6Y,
	nvl(a.total_acv_T_M7Y, 0) total_acv_T_M7Y, 
	nvl(a.core_acv_T_M7Y, 0) core_acv_T_M7Y, 
	nvl(a.mc_acv_T_M7Y, 0) mc_acv_T_M7Y, 
	nvl(a.cc_acv_T_M7Y, 0) cc_acv_T_M7Y,
	nvl(a.core_acv_FY21, 0) core_acv_FY21, 
	nvl(a.mc_acv_FY21, 0) mc_acv_FY21, 
	nvl(a.cc_acv_FY21, 0) cc_acv_FY21,
	nvl(a.total_acv_historical, 0) total_acv_historical,
	nvl(a.core_acv_historical, 0) core_acv_historical,
	nvl(a.mc_acv_histoircal, 0) mc_acv_historical,
	nvl(a.cc_acv_histoircal, 0) cc_acv_historical,
	nvl(b.T_M0Y_pred,0) T_M0Y_pred, 
	nvl(b.T_M1Y_pred, 0) T_M1Y_pred, 
	nvl(b.T_M2Y_pred, 0) T_M2Y_pred, 
	nvl(b.T_M3Y_pred, 0) T_M3Y_pred 
	
FROM 
	(SELECT  
		acct_id acct_id_acv,
		sum(CASE WHEN acv.PERIOD = 'T_M0Y' THEN acv.total_acv ELSE 0 END ) total_acv_T_M0Y,
		sum(CASE WHEN acv.PERIOD = 'T_M0Y' THEN acv.core_acv ELSE 0 END ) core_acv_T_M0Y,
		sum(CASE WHEN acv.PERIOD = 'T_M0Y' THEN acv.mc_acv ELSE 0 END ) mc_acv_T_M0Y,
		sum(CASE WHEN acv.PERIOD = 'T_M0Y' THEN acv.cc_acv ELSE 0 END ) cc_acv_T_M0Y,
		sum(CASE WHEN acv.PERIOD = 'T_M1Y' THEN acv.total_acv ELSE 0 END ) total_acv_T_M1Y,
		sum(CASE WHEN acv.PERIOD = 'T_M1Y' THEN acv.core_acv ELSE 0 END ) core_acv_T_M1Y,
		sum(CASE WHEN acv.PERIOD = 'T_M1Y' THEN acv.mc_acv ELSE 0 END ) mc_acv_T_M1Y,
		sum(CASE WHEN acv.PERIOD = 'T_M1Y' THEN acv.cc_acv ELSE 0 END ) cc_acv_T_M1Y,
		sum(CASE WHEN acv.PERIOD = 'T_M2Y' THEN acv.total_acv ELSE 0 END ) total_acv_T_M2Y,
		sum(CASE WHEN acv.PERIOD = 'T_M2Y' THEN acv.core_acv ELSE 0 END ) core_acv_T_M2Y,
		sum(CASE WHEN acv.PERIOD = 'T_M2Y' THEN acv.mc_acv ELSE 0 END ) mc_acv_T_M2Y,
		sum(CASE WHEN acv.PERIOD = 'T_M2Y' THEN acv.cc_acv ELSE 0 END ) cc_acv_T_M2Y,
		sum(CASE WHEN acv.PERIOD = 'T_M3Y' THEN acv.total_acv ELSE 0 END ) total_acv_T_M3Y,
		sum(CASE WHEN acv.PERIOD = 'T_M3Y' THEN acv.core_acv ELSE 0 END ) core_acv_T_M3Y,
		sum(CASE WHEN acv.PERIOD = 'T_M3Y' THEN acv.mc_acv ELSE 0 END ) mc_acv_T_M3Y,
		sum(CASE WHEN acv.PERIOD = 'T_M3Y' THEN acv.cc_acv ELSE 0 END ) cc_acv_T_M3Y,
		sum(CASE WHEN acv.PERIOD = 'T_M4Y' THEN acv.total_acv ELSE 0 END ) total_acv_T_M4Y,
		sum(CASE WHEN acv.PERIOD = 'T_M4Y' THEN acv.core_acv ELSE 0 END ) core_acv_T_M4Y,
		sum(CASE WHEN acv.PERIOD = 'T_M4Y' THEN acv.mc_acv ELSE 0 END ) mc_acv_T_M4Y,
		sum(CASE WHEN acv.PERIOD = 'T_M4Y' THEN acv.cc_acv ELSE 0 END ) cc_acv_T_M4Y,
		sum(CASE WHEN acv.PERIOD = 'T_M5Y' THEN acv.total_acv ELSE 0 END ) total_acv_T_M5Y,
		sum(CASE WHEN acv.PERIOD = 'T_M5Y' THEN acv.core_acv ELSE 0 END ) core_acv_T_M5Y,
		sum(CASE WHEN acv.PERIOD = 'T_M5Y' THEN acv.mc_acv ELSE 0 END ) mc_acv_T_M5Y,
		sum(CASE WHEN acv.PERIOD = 'T_M5Y' THEN acv.cc_acv ELSE 0 END ) cc_acv_T_M5Y,
		sum(CASE WHEN acv.PERIOD ='T_M6Y' THEN acv.total_acv ELSE 0 END )  total_acv_T_M6Y,
		sum(CASE WHEN acv.PERIOD ='T_M6Y' THEN acv.core_acv ELSE 0 END ) core_acv_T_M6Y,
		sum(CASE WHEN acv.PERIOD ='T_M6Y' THEN acv.mc_acv ELSE 0 END ) mc_acv_T_M6Y,
		sum(CASE WHEN acv.PERIOD ='T_M6Y' THEN acv.cc_acv ELSE 0 END ) cc_acv_T_M6Y,
		sum(CASE WHEN acv.PERIOD = 'T_M7Y' THEN acv.total_acv ELSE 0 END ) total_acv_T_M7Y,
		sum(CASE WHEN acv.PERIOD = 'T_M7Y' THEN acv.core_acv ELSE 0 END ) core_acv_T_M7Y,
		sum(CASE WHEN acv.PERIOD = 'T_M7Y' THEN acv.mc_acv ELSE 0 END ) mc_acv_T_M7Y,
		sum(CASE WHEN acv.PERIOD = 'T_M7Y' THEN acv.cc_acv ELSE 0 END ) cc_acv_T_M7Y,
		sum(CASE WHEN acv.PERIOD = 'FY21' THEN acv.core_acv ELSE 0 END ) core_acv_FY21,
		sum(CASE WHEN acv.PERIOD = 'FY21' THEN acv.mc_acv ELSE 0 END ) mc_acv_FY21,
		sum(CASE WHEN acv.PERIOD = 'FY21' THEN acv.cc_acv ELSE 0 END ) cc_acv_FY21,
		sum(CASE WHEN acv.PERIOD IN ('T_M0Y','T_M1Y','T_M2Y','T_M3Y') THEN acv.total_acv ELSE 0 END )  total_acv_historical,
		sum(CASE WHEN acv.PERIOD IN ('T_M0Y','T_M1Y','T_M2Y','T_M3Y') THEN acv.core_acv ELSE 0 END ) core_acv_historical,
		sum(CASE WHEN acv.PERIOD IN ('T_M0Y','T_M1Y','T_M2Y','T_M3Y') THEN acv.mc_acv ELSE 0 END ) mc_acv_histoircal,
		sum(CASE WHEN acv.PERIOD IN ('T_M0Y','T_M1Y','T_M2Y','T_M3Y') THEN acv.cc_acv ELSE 0 END ) cc_acv_histoircal
	from AIG4G_ACCT_ACV_FY acv 
	GROUP BY acct_id) a 
	FULL JOIN 
	(SELECT 
		acct_id acct_id_pred,
		sum(CASE WHEN pred.PERIOD = 'T_M0Y' THEN pred.ACCT_ACV_POTENTIAL ELSE 0 end) T_M0Y_pred, 
		sum(CASE WHEN pred.PERIOD = 'T_M1Y' THEN pred.ACCT_ACV_POTENTIAL ELSE 0 end) T_M1Y_pred, 
		sum(CASE WHEN pred.PERIOD = 'T_M2Y' THEN pred.ACCT_ACV_POTENTIAL ELSE 0 end) T_M2Y_pred, 
		sum(CASE WHEN pred.PERIOD = 'T_M3Y' THEN pred.ACCT_ACV_POTENTIAL ELSE 0 end) T_M3Y_pred
		
	FROM AIG4G_ACCT_ACV_PRED_FY pred 
	GROUP BY acct_id) b 
	ON a.acct_id_acv = b.acct_id_pred
	@


	

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE AIG4G_ACCT_INDUSTRY';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@

CREATE TABLE AIG4G_ACCT_INDUSTRY AS 
SELECT /*+PARALLEL(16)*/
	b.acct_id, 
	nvl(a.locked_industry, b.industry_nm) industry
FROM (SELECT acct_id, LOCKED_INDUSTRY, INDUSTRY_NM, substr(locked_company,0,15) co_id from dm.dim_account WHERE CURR_REC_FLG = 'Y' AND DEL_FLG = 'N') b 
LEFT JOIN (SELECT co_id_15, locked_industry FROM dm.dim_company WHERE del_flg = 'N') a ON a.co_id_15 = b.co_id
@
	


BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE aig4g_qcp_hier_acv_fy';
EXCEPTION
    WHEN OTHERS THEN
        IF
            SQLCODE !=-942
        THEN
            RAISE;
        END IF;
END;
@

CREATE TABLE aig4g_qcp_hier_acv_fy AS
WITH a AS (SELECT /*+PARALLEL(16)*/
	qcp.ORG62_ACCOUNT_ID,
	qcp.l2_res_user_name,
	qcp.l3_res_user_name,
	qcp.l4_res_user_name,
	qcp.l5_res_user_name,
	qcp.l6_res_user_name,
	qcp.l7_res_user_name,
	qcp.l8_res_user_name,
	qcp.leaf_terr_name,
	qcp.PRIORTIZED_MARKETSEGMENT,
	qcp.PRIORTIZED_SUBREGION,
	qcp.PRIORTIZED_VERTICAL,
	qcp.PRIORTIZED_MARKETSEGMENT || ' ' || qcp.PRIORTIZED_SUBREGION || ' ' || qcp.PRIORTIZED_VERTICAL territory_nm, 
	ind.industry,
	sum(a.total_acv_T_M0Y) total_acv_T_M0Y, 
	sum(a.core_acv_T_M0Y) core_acv_T_M0Y, 
	sum(a.mc_acv_T_M0Y) mc_acv_T_M0Y, 
	sum(a.cc_acv_T_M0Y) cc_acv_T_M0Y,
	sum(a.total_acv_T_M1Y) total_acv_T_M1Y, 
	sum(a.core_acv_T_M1Y) core_acv_T_M1Y, 
	sum(a.mc_acv_T_M1Y) mc_acv_T_M1Y, 
	sum(a.cc_acv_T_M1Y) cc_acv_T_M1Y,
	sum(a.total_acv_T_M2Y) total_acv_T_M2Y, 
	sum(a.core_acv_T_M2Y) core_acv_T_M2Y, 
	sum(a.mc_acv_T_M2Y) mc_acv_T_M2Y, 
	sum(a.cc_acv_T_M2Y) cc_acv_T_M2Y, 
	sum(a.total_acv_T_M3Y) total_acv_T_M3Y, 
	sum(a.core_acv_T_M3Y) core_acv_T_M3Y, 
	sum(a.mc_acv_T_M3Y) mc_acv_T_M3Y, 
	sum(a.cc_acv_T_M3Y) cc_acv_T_M3Y,
	sum(a.total_acv_T_M4Y) total_acv_T_M4Y, 
	sum(a.core_acv_T_M4Y) core_acv_T_M4Y, 
	sum(a.mc_acv_T_M4Y) mc_acv_T_M4Y, 
	sum(a.cc_acv_T_M4Y) cc_acv_T_M4Y,
	sum(a.total_acv_T_M5Y) total_acv_T_M5Y, 
	sum(a.core_acv_T_M5Y) core_acv_T_M5Y, 
	sum(a.mc_acv_T_M5Y) mc_acv_T_M5Y, 
	sum(a.cc_acv_T_M5Y) cc_acv_T_M5Y,
	sum(a.total_acv_T_M6Y) total_acv_T_M6Y, 
	sum(a.core_acv_T_M6Y) core_acv_T_M6Y, 
	sum(a.mc_acv_T_M6Y) mc_acv_T_M6Y, 
	sum(a.cc_acv_T_M6Y) cc_acv_T_M6Y,
	sum(a.total_acv_T_M7Y) total_acv_T_M7Y, 
	sum(a.core_acv_T_M7Y) core_acv_T_M7Y, 
	sum(a.mc_acv_T_M7Y) mc_acv_T_M7Y, 
	sum(a.cc_acv_T_M7Y) cc_acv_T_M7Y,
	sum(a.core_acv_FY21) core_acv_FY21, 
	sum(a.mc_acv_FY21) mc_acv_FY21, 
	sum(a.cc_acv_FY21) cc_acv_FY21,
	sum(a.total_acv_historical) total_acv_historical,
	sum(a.core_acv_historical) core_acv_historical,
	sum(a.mc_acv_historical) mc_acv_historical,
	sum(a.cc_acv_historical) cc_acv_historical,
	sum(a.T_M0Y_pred) T_M0Y_pred,
	sum(a.T_M1Y_pred) T_M1Y_pred,
	sum(a.T_M2Y_pred) T_M2Y_pred, 
	sum(a.T_M3Y_pred) T_M3Y_pred,	
	CASE WHEN sum(a.total_acv_historical) = 0 THEN 0 
		ELSE sum(a.core_acv_historical)/sum(a.total_acv_historical) 
	END core_perc_hist,
	CASE WHEN sum(a.total_acv_historical) = 0 THEN 0 
		ELSE sum(a.mc_acv_historical)/sum(a.total_acv_historical) 
	END mc_perc_hist,
	CASE WHEN sum(a.total_acv_historical) = 0 THEN 0 
		ELSE sum(a.cc_acv_historical)/sum(a.total_acv_historical) 
	END cc_perc_hist,
	sum(aov.T_M0Y_aov) T_M0Y_aov, 
	sum(aov.T_M0Y_core_aov) T_M0Y_core_aov, 
	sum(aov.T_M0Y_mc_aov) T_M0Y_mc_aov,
	sum(aov.T_M0Y_cc_aov) T_M0Y_cc_aov, 
	sum(aov.T_M1Y_aov) T_M1Y_aov, 
	sum(aov.T_M1Y_core_aov) T_M1Y_core_aov, 
	sum(aov.T_M1Y_mc_aov) T_M1Y_mc_aov,
	sum(aov.T_M1Y_cc_aov) T_M1Y_cc_aov, 
	sum(aov.T_M2Y_aov) T_M2Y_aov, 
	sum(aov.T_M2Y_core_aov) T_M2Y_core_aov, 
	sum(aov.T_M2Y_mc_aov) T_M2Y_mc_aov,
	sum(aov.T_M2Y_cc_aov) T_M2Y_cc_aov, 
	sum(aov.T_M3Y_aov) T_M3Y_aov, 
	sum(aov.T_M3Y_core_aov) T_M3Y_core_aov, 
	sum(aov.T_M3Y_mc_aov) T_M3Y_mc_aov,
	sum(aov.T_M3Y_cc_aov) T_M3Y_cc_aov, 
	sum(aov.T_M4Y_aov) T_M4Y_aov, 
	sum(aov.T_M4Y_core_aov) T_M4Y_core_aov, 
	sum(aov.T_M4Y_mc_aov) T_M4Y_mc_aov,
	sum(aov.T_M4Y_cc_aov) T_M4Y_cc_aov,
	sum(op.T_M0Y_op) T_M0Y_op, 
	sum(op.T_M0Y_core_op) T_M0Y_core_op, 
	sum(op.T_M0Y_mc_op) T_M0Y_mc_op, 
	sum(op.T_M0Y_cc_op) T_M0Y_cc_op ,
	sum(op.T_M1Y_op) T_M1Y_op, 
	sum(op.T_M1Y_core_op) T_M1Y_core_op, 
	sum(op.T_M1Y_mc_op) T_M1Y_mc_op, 
	sum(op.T_M1Y_cc_op) T_M1Y_cc_op ,
	sum(op.T_M2Y_op) T_M2Y_op, 
	sum(op.T_M2Y_core_op) T_M2Y_core_op, 
	sum(op.T_M2Y_mc_op) T_M2Y_mc_op, 
	sum(op.T_M2Y_cc_op) T_M2Y_cc_op ,
	sum(op.T_M3Y_op) T_M3Y_op, 
	sum(op.T_M3Y_core_op) T_M3Y_core_op, 
	sum(op.T_M3Y_mc_op) T_M3Y_mc_op, 
	sum(op.T_M3Y_cc_op) T_M3Y_cc_op ,
	sum(op.T_M4Y_op) T_M4Y_op, 
	sum(op.T_M4Y_core_op) T_M4Y_core_op, 
	sum(op.T_M4Y_mc_op) T_M4Y_mc_op, 
	sum(op.T_M4Y_cc_op) T_M4Y_cc_op 
FROM MRICHING.FY22_QCP_ACCTS qcp 
LEFT JOIN AIG4G_ACV_BACKTEST_FY a 
ON a.acct_id = substr(qcp.ORG62_ACCOUNT_ID,0,15)
LEFT JOIN AIG4G_aov_backtest_fy aov 
ON aov.acct_id = substr(qcp.ORG62_ACCOUNT_ID,0,15) 
LEFT JOIN AIG4G_ftm_op_fy op 
ON op.acct_id = substr(qcp.ORG62_ACCOUNT_ID, 0, 15)
LEFT JOIN AIG4G_ACCT_INDUSTRY ind
ON ind.acct_id = substr(qcp.ORG62_ACCOUNT_ID,0,15)
GROUP BY 
	qcp.l2_res_user_name,
	qcp.l3_res_user_name,
	qcp.l4_res_user_name,
	qcp.l5_res_user_name,
	qcp.l6_res_user_name,
	qcp.l7_res_user_name,
	qcp.l8_res_user_name,
	qcp.leaf_terr_name,
	qcp.PRIORTIZED_MARKETSEGMENT,
	qcp.PRIORTIZED_SUBREGION,
	qcp.PRIORTIZED_VERTICAL,
	qcp.PRIORTIZED_MARKETSEGMENT || ' ' || qcp.PRIORTIZED_SUBREGION || ' ' || qcp.PRIORTIZED_VERTICAL ,
	ind.industry,
	qcp.ORG62_ACCOUNT_ID
)
SELECT 
	a.*, 
	a.T_M0Y_pred*core_perc_hist T_M0Y_pred_core ,
	a.T_M0Y_pred*mc_perc_hist T_M0Y_pred_mc , 
	a.T_M0Y_pred*cc_perc_hist T_M0Y_pred_cc ,  
	a.T_M1Y_pred*core_perc_hist T_M1Y_pred_core ,
	a.T_M1Y_pred*mc_perc_hist T_M1Y_pred_mc , 
	a.T_M1Y_pred*cc_perc_hist T_M1Y_pred_cc , 
	a.T_M2Y_pred*core_perc_hist T_M2Y_pred_core, 
	a.T_M2Y_pred*mc_perc_hist T_M2Y_pred_mc, 
	a.T_M2Y_pred*cc_perc_hist T_M2Y_pred_cc , 
	a.T_M3Y_pred*core_perc_hist T_M3Y_pred_core, 
	a.T_M3Y_pred*mc_perc_hist T_M3Y_pred_mc, 
	a.T_M3Y_pred*cc_perc_hist T_M3Y_pred_cc 
FROM a 
@
select * from aig4g_qcp_hier_acv_fy