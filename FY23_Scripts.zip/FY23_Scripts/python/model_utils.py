'''
	ACV Prediction model based on GSI and Pricing models + trailing ACV. 
	
	Functions and script for running the models

'''

import numpy as np
import pandas as pd
import random
import getpass
import json
import sys,os,logging
import datetime
import pickle 

import warnings
warnings.filterwarnings("ignore")

np.random.seed(10)
random.seed(10)


# Utils
import max_distribution as max_dist
import perf_metric_utils as m_utils


# Grid search
from sklearn.model_selection import  ParameterGrid,ParameterSampler

#Hyperopt
from hyperopt import fmin, tpe, hp
import hyperopt.pyll.stochastic
from hyperopt import fmin, tpe, hp, STATUS_OK, Trials


#Regular performance metrics
from scipy import stats
import scipy.stats as sp_stat
from scipy.stats import pearsonr
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression



## Global vars
template_evals = [  "T_M{}Y_PRED" ,             
    "T_M{}Y_PRED_CORE",         
    "T_M{}Y_PRICING_PRED_CORE", 
    "T_M{}Y_PRICING_PRED",
    "CORE_T12_T_M{}Y",          
    "CORE_T24_T_M{}Y",          
    "CORE_T36_T_M{}Y",          ]


normal_rand_range = np.abs(np.append(np.random.normal(.5,1,50),[0]))
my_param_grid_norm_range = {
    "T_M{}Y_PRED" :             normal_rand_range,
    "T_M{}Y_PRED_CORE":         normal_rand_range,
    "T_M{}Y_PRICING_PRED_CORE": normal_rand_range,
    "T_M{}Y_PRICING_PRED":normal_rand_range,
    "CORE_T12_T_M{}Y":          normal_rand_range,
    "CORE_T24_T_M{}Y":          normal_rand_range,
    "CORE_T36_T_M{}Y":          normal_rand_range,
    }


# Use all 3 years of history for training
FY_RANGE_FULL = range(0,3) 

# Use last year for validation
FY_RANGE_TRAIN = range(1,3) # Years T - (2,3)
FY_RANGE_TEST = range(0,1)  # Year T - 1



best_params_ous = {}

perf_eval_cols_full = {
    "T_M2Y": ['CORE_T12_T_M2Y', 'CORE_T24_T_M2Y', 'CORE_T36_T_M2Y'],
    "T_M1Y": ['CORE_T12_T_M1Y', 'CORE_T24_T_M1Y', 'CORE_T36_T_M1Y'],
    "T_M0Y": ['CORE_T12_T_M0Y', 'CORE_T24_T_M0Y', 'CORE_T36_T_M0Y'],
    "eval_name": ['TTM', 'TTM_2yr', 'TTM_3yr']
}

perf_eval_cols_train = {
    "T_M2Y": ['CORE_T12_T_M2Y', 'CORE_T24_T_M2Y', 'CORE_T36_T_M2Y'],
    "T_M1Y": ['CORE_T12_T_M1Y', 'CORE_T24_T_M1Y', 'CORE_T36_T_M1Y'],
    "eval_name": ['TTM','TTM_2yr', 'TTM_3yr']
}


perf_eval_cols_test = {
    "T_M0Y": ['CORE_T12_T_M0Y', 'CORE_T24_T_M0Y', 'CORE_T36_T_M0Y'],
    "eval_name": ['TTM','TTM_2yr', 'TTM_3yr']
}



GROUPS = {
    "AMER": {'QCP':('L4_RES_USER_NAME','L5_RES_USER_NAME')
            ,'Carving':('L4_RES_USER_NAME','LEAF_TERR_NAME')
            ,'OU_P2':('L4_RES_USER_NAME','L6_RES_USER_NAME')
            ,'OU_P3':('L4_RES_USER_NAME','L7_RES_USER_NAME')
            ,'OU_P4':('L4_RES_USER_NAME','L8_RES_USER_NAME')},
    "INTL": {'QCP':('L3_RES_USER_NAME','L4_RES_USER_NAME')
            ,'Carving':('L3_RES_USER_NAME','LEAF_TERR_NAME')
            ,'OU_P2':('L3_RES_USER_NAME','L5_RES_USER_NAME')
            ,'OU_P3':('L3_RES_USER_NAME','L6_RES_USER_NAME')
            ,'OU_P4':('L3_RES_USER_NAME','L7_RES_USER_NAME')}
}


################ Util functions ####################

def flatten_groups(groups_map):
	'''
	 Utility to translate between two different formats for the grouping sets.
	'''
    flat_map = {}
    for key in groups_map.keys():
        grp1 = []
        grp2 = []
        for subkey in groups_map[key].keys():
            grp1 = grp1 + [groups_map[key][subkey][0]]
            grp2 = grp2 + [groups_map[key][subkey][1]]
        flat_map[key] = (grp1,grp2)
    return flat_map


def cols_by_fy(cols_template, fy):
    """
    Get FY Columns based on `cols_template`. 
    Make sure that each item in cols_template has only one format string option

    Parameters
    ----------
    cols: list
    Column name with template

    fy: int
    Fiscal year
    
    Returns
    -------
    list
        List of FY Columns
    
    """
    return [ x.format(fy) for x in cols_template]



def predict_best_param(df, fy, best_param, pred_weight=1.0):
    """Generates blended ACV value based on `best param` and fiscal year
    Parameters
    ----------
    df : dataframe
        data used to compute distribution error
    fy : int
        fiscal year
    best_param : dict
        Best paramter for weights
    pred_weight : float
    	Optional weigh param to adjust absolute prediction values

    Returns
    -------
    (dict, df)
    
    """
    cols = cols_by_fy(best_param.keys(), fy)
    total = sum(best_param.values()) * pred_weight 
    return (df[cols] * list(best_param.values())/total).sum(1) 


def score_param(df, grp1, grp2, fy, param_id, param, perf_eval_cols, predict_val=None):
    """"Generates scores for parameter based on grp1, grp2, fy
    Performance are evaluated across `perf_eval_cols` to generate performance, margin and score columns
    
    Parameters
    ----------
    df : dataframe
        data used to compute distribution error
    grp1 : str
        Group1 used to generate distribution error
    grp2 : str
        Group2 used to generate distribution error
    fy : int
        fiscal year
    param_id : int
        param_id
    param : dict
        Parameter values to run score on
    perf_eval_cols : dict
        Evaluation column grouped by fiscal year and also final labels to be given to each evaluation
    predict_val : Series, default = None
            Prediction numbers to use instead of computing numbers
    Returns
    -------
    (Series, err_ser) : 
    
    
    """
    def get_raw_dist(pred):
        """
        Get distribution err from max and return raw numbers
        """
        cmp_cols = ['best_predict_'] + perf_eval_cols[f"T_M{fy}Y"]
        lbl_cols = ['best_predict_'] + perf_eval_cols['eval_name']
        
        dist_err = max_dist.dist_ou_raw_err(
        grp1, grp2,  df.eval('best_predict_ = @pred'), f'CORE_ACV_T_M{fy}Y', cmp_cols)
        # filter raw error
        raw_err = [v for k, v in dist_err[0].items() if 'raw' in k]
        return pd.Series(raw_err, lbl_cols)
    
    def negative_check(df_check, err):
        """
        check if the grp1 and grp2 sum should not have negative pred ACV
        
        Test negative cases and update err to inf 
        """
        min_grp_pred = df_check.groupby([grp1, grp2])['best_predict_'].sum().min()
        if min_grp_pred < 0 :
            err['best_predict_'] = np.inf
        return err
    
        
    perf_ttm_lbl = perf_eval_cols['eval_name']
    pred = predict_best_param(df, fy, param) if predict_val is None else predict_val
    
    # Get error performance
    err_ser = get_raw_dist(pred)
    
    # check if the grp1 and grp2 sum should not have negative pred ACV
    df_check = df.eval('best_predict_ = @pred')
    err_ser = negative_check(df_check, err_ser)
    
    # Running performance based on perf_ttm_lbl
    err_ser['performance'] = (err_ser[perf_ttm_lbl] > err_ser.best_predict_).sum()
    err_ser['margin'] = (err_ser[perf_ttm_lbl] - err_ser.best_predict_).mean()
    # Score is a combination of err_margin and err_perf
    err_ser['score']= err_ser['performance'] + err_ser['margin']
    err_ser['uplift'] = (err_ser[perf_ttm_lbl].mean()/err_ser['best_predict_'] - 1)
    
    err_ser['param'] = param
    err_ser['param_id'] = param_id
    err_ser['FY'] = fy
    return err_ser

    
    
def optimize_performance(df, fy_range,grp1, grp2, my_param_grid, perf_eval_cols, n_iter=1000, verbose = True):
    """
    Optimize and generate best parameter based on my_param_grid. Uses random search to get best param

    Parameters
    ----------
    df : dataframe
        Data used to generate best paramter
    grp1 : list
        Group1 used to generate distribution error
    grp2 : list
        Group2 used to generate distribution error
    my_param_grid : dict
        Parameter grid
    perf_eval_cols : dict
        Evaluation column grouped by fiscal year and also final labels to be given to each evaluation
    n_iter : int, optional
        number of iteration to run for random grid search, by default 1000
    verbose : bool, optional
        Show detailed summary of results, by default True
    Returns
    -------
    dict, df
        dict: best parameter with high marging
        df: result of all the parameter search and its associated distribution performance  compared to perf_eval_cols
    
    """
    def executor(df, grp1, grp2, param_id, param, perf_eval_cols):
        res = []
        for fy in fy_range:
            qcp_ser = score_param(df, grp1[0], grp2[0], fy, param_id, param, perf_eval_cols)
            qcp_ser['Type'] = "QCP"
            
            carv_ser = score_param(df, grp1[1], grp2[1], fy, param_id, param, perf_eval_cols)
            carv_ser['Type'] = "Carving"
            
            lvl2_ser = score_param(df, grp1[2], grp2[2], fy, param_id, param, perf_eval_cols)
            lvl2_ser['Type'] = "OU_P2"
            
            lvl3_ser = score_param(df, grp1[3], grp2[3], fy, param_id, param, perf_eval_cols)
            lvl3_ser['Type'] = "OU_P3"
          
            lvl4_ser = score_param(df, grp1[4], grp2[4], fy, param_id, param, perf_eval_cols)
            lvl4_ser['Type'] = "OU_P4"
          
            
            
            res.append(pd.DataFrame([qcp_ser, carv_ser,lvl2_ser,lvl3_ser,lvl4_ser]))
        return pd.concat(res)

    ou = df[grp1[0]].iloc[0]
    logging.info("Running for OU : "+ou)
    from joblib import Parallel, delayed
    from tqdm import tqdm
    param_sampler = ParameterSampler(my_param_grid, n_iter=n_iter, random_state=np.random.RandomState(0))
    res = Parallel(n_jobs=-1)(delayed(executor)(df,grp1,grp2, i, param, perf_eval_cols) for i,param in tqdm(enumerate(param_sampler)))
    
    res_df = pd.concat(res)
    res_df['OU'] = ou
    return res_df

    
    

    
def uplift_train(x, perf_ttm_lbl = perf_eval_cols_train['eval_name']):
    """
    Run uplift analysis on `best_predict_` column against perf_ttm_lbl
    Parameters
    ----------
    x : dataframe
        Data used to generate uplift
    perf_ttm_lbl : list
        List of column in x to run performance comparison against `best_predict_`
    Returns
    -------
    Series, ser
        Uplift numbers
    """
    return pd.Series({"uplift":x[perf_ttm_lbl].mean() / x['best_predict_'] -1})



def uplift_test(x, perf_ttm_lbl = perf_eval_cols_test['eval_name']):
    """
    Run uplift analysis for test columns
    ----------
    x : dataframe
        Data used to generate uplift
    perf_ttm_lbl : list
        List of column in x to run performance comparison against `best_predict_`
    Returns
    -------
    Series, ser
        Uplift numbers
    """
    return uplift_train(x, perf_ttm_lbl)
    ##return pd.Series({"uplift":x[perf_ttm_lbl].mean() / x['best_predict_'] -1})



def optimize_performance_bayes(df,fy_range,groups1, groups2, param_space, perf_eval_cols, n_iter=100, verbose = False):
    '''
    Tries to improve the distribution accuracy performace with a Bayesian search and returns the best parameter values. 
    This function is intended to be used after grid search. The bayesian search is computationally more expesive process and will 
    only try to improve upon the best parameter values found during the grid search.

	-----
	dy - Data Frame
		Copy of the training data
	fy_range - list
		List of FY to predict for
	groups1 - string
		First groping level
	groups2 - strong
		Second grouping level
	param_space - dict
		Initial parameter values
	perf_eval_cols - list
		Performace evaluation columns list
	n_iter - integer
		Number of iterations for the Bayes search
	verbose - boolean
		Logging level flag

	Return:
		best
			Search parameters and new parameter values
		best_score
			Best score found in the bayesian search


    '''
    
    # Init score 
    best_score = 10**6 * -1
    
    # Store performance for TTMs
    err_ttm = []
    df_ttm = pd.DataFrame()

    for fy in fy_range:
        
        cols = perf_eval_cols[f'T_M{fy}Y']
        
        # QCP Performance
        err = max_dist.dist_ou_raw_err(groups1[0], groups2[0],  df, f'CORE_ACV_T_M{fy}Y', cols)
        df_tmp = pd.DataFrame({'Eval':['QCP'],'FY':[fy],'T12':err[0][f'CORE_T12_T_M{fy}Y_raw_err'],'T24':err[0][f'CORE_T24_T_M{fy}Y_raw_err'],'T36':err[0][f'CORE_T36_T_M{fy}Y_raw_err']})
        df_ttm = df_ttm.append(df_tmp)
        
        # Carving Performance
        err = max_dist.dist_ou_raw_err(groups1[1], groups2[1],  df, f'CORE_ACV_T_M{fy}Y', cols)
        df_tmp = pd.DataFrame({'Eval':['Carving'],'FY':[fy],'T12':err[0][f'CORE_T12_T_M{fy}Y_raw_err'],'T24':err[0][f'CORE_T24_T_M{fy}Y_raw_err'],'T36':err[0][f'CORE_T36_T_M{fy}Y_raw_err']})
        df_ttm = df_ttm.append(df_tmp)
      
        
        # OU + 2
        err = max_dist.dist_ou_raw_err(groups1[2], groups2[2],  df, f'CORE_ACV_T_M{fy}Y', cols)
        df_tmp = pd.DataFrame({'Eval':['OU_P2'],'FY':[fy],'T12':err[0][f'CORE_T12_T_M{fy}Y_raw_err'],'T24':err[0][f'CORE_T24_T_M{fy}Y_raw_err'],'T36':err[0][f'CORE_T36_T_M{fy}Y_raw_err']})
        df_ttm = df_ttm.append(df_tmp)
      
         # OU + 3
        err = max_dist.dist_ou_raw_err(groups1[3], groups2[3],  df, f'CORE_ACV_T_M{fy}Y', cols)
        df_tmp = pd.DataFrame({'Eval':['OU_P3'],'FY':[fy],'T12':err[0][f'CORE_T12_T_M{fy}Y_raw_err'],'T24':err[0][f'CORE_T24_T_M{fy}Y_raw_err'],'T36':err[0][f'CORE_T36_T_M{fy}Y_raw_err']})
        df_ttm = df_ttm.append(df_tmp)
        
        # OU + 4
        err = max_dist.dist_ou_raw_err(groups1[4], groups2[4],  df, f'CORE_ACV_T_M{fy}Y', cols)
        df_tmp = pd.DataFrame({'Eval':['OU_P4'],'FY':[fy],'T12':err[0][f'CORE_T12_T_M{fy}Y_raw_err'],'T24':err[0][f'CORE_T24_T_M{fy}Y_raw_err'],'T36':err[0][f'CORE_T36_T_M{fy}Y_raw_err']})
        df_ttm = df_ttm.append(df_tmp)
   
        
   
    df_ttm = df_ttm.reset_index(drop=True)
    
    
    # Objective function
    def dist_loss(params):
        
        nonlocal best_score
        
        wt = params.values()
        df_pred = pd.DataFrame()
        for fy in fy_range:
        
            df['Pred1'] = predict_best_param(df,fy,params)
            
            # QCP Performance
            err = max_dist.dist_ou_raw_err(groups1[0], groups2[0],  df, f'CORE_ACV_T_M{fy}Y', ['Pred1'])
            df_tmp = pd.DataFrame({'Eval':['QCP'],'FY':[fy],'Pred1':err[0]['Pred1_raw_err']})
            df_pred = df_pred.append(df_tmp)
            
            # Carving Performance
            err = max_dist.dist_ou_raw_err(groups1[1], groups2[1],  df, f'CORE_ACV_T_M{fy}Y', ['Pred1'])
            df_tmp = pd.DataFrame({'Eval':['Carving'],'FY':[fy],'Pred1':err[0]['Pred1_raw_err']})
            df_pred = df_pred.append(df_tmp)
       
            # OU + 2
            err = max_dist.dist_ou_raw_err(groups1[2], groups2[2],  df, f'CORE_ACV_T_M{fy}Y', ['Pred1'])
            df_tmp = pd.DataFrame({'Eval':['OU_P2'],'FY':[fy],'Pred1':err[0]['Pred1_raw_err']})
            df_pred = df_pred.append(df_tmp)
       
            # OU + 3
            err = max_dist.dist_ou_raw_err(groups1[3], groups2[3],  df, f'CORE_ACV_T_M{fy}Y', ['Pred1'])
            df_tmp = pd.DataFrame({'Eval':['OU_P3'],'FY':[fy],'Pred1':err[0]['Pred1_raw_err']})
            df_pred = df_pred.append(df_tmp)
            
             # OU + 4
            err = max_dist.dist_ou_raw_err(groups1[4], groups2[4],  df, f'CORE_ACV_T_M{fy}Y', ['Pred1'])
            df_tmp = pd.DataFrame({'Eval':['OU_P4'],'FY':[fy],'Pred1':err[0]['Pred1_raw_err']})
            df_pred = df_pred.append(df_tmp)
       
            
        df_pred = df_pred.reset_index(drop=True)
        df_eval = df_pred.join(df_ttm,how='inner',lsuffix='_pred', rsuffix='_ttms')
        df_eval['W_T12']=np.where(df_eval['Pred1']<df_eval['T12'],1,0)
        df_eval['W_T24']=np.where(df_eval['Pred1']<df_eval['T24'],1,0)
        df_eval['W_T36']=np.where(df_eval['Pred1']<df_eval['T36'],1,0)
        df_eval['W_Margin']= (df_eval['T12']+df_eval['T24']+df_eval['T36'])/3 - df_eval['Pred1']
        
        score = (df_eval['W_T12'].sum() + df_eval['W_T24'].sum() + df_eval['W_T36'].sum()) + df_eval['W_Margin'].mean()
        if score > best_score:
            best_score = score
            
        return score * -1
        
     
    trials = Trials() # We can analyze these later, but for now ignored.
    best = fmin(fn=dist_loss, space=param_space, algo=tpe.suggest, max_evals=n_iter, trials=trials)
    return best,best_score






def reg_perf_metrics(df_dat_grp,df_eval):
	'''
	Calculate regular model performance metrics: MAE, MAPE, RMSE, Correlation (Pearson) and R2

	df_dat_grp - Data Frame
		OU data grouped in the second grouping level
	df_eval - Data Frame
		Evaluation metrics

	Return
		df_eval
			Evaluation data with performance metrics added

	'''
    
    metr_cols = df_dat_grp.columns[1:]
    for col in metr_cols:
        if df_dat_grp.shape[0]>1:
            met_res = m_utils.evaluate(np.array(df_dat_grp[['Actual']]),np.array(df_dat_grp[[col]]),metrics=['mae','rmse'])
            corr, _ = pearsonr(np.array(df_dat_grp['Actual']), np.array(df_dat_grp[col]))
            r2 = r2_score(np.array(df_dat_grp['Actual']), np.array(df_dat_grp[col]))
            df_eval[col+'_mae'] = met_res['mae']
            mean_actual = df_dat_grp['Actual'].mean()
            if mean_actual == 0:
                df_eval[col+'_mape'] = 0
            else:
                df_eval[col+'_mape'] = round(abs(met_res['mae']/mean_actual),4)
            df_eval[col+'_rmse'] = met_res['rmse']
            df_eval[col+'_pears_corr'] = corr
            df_eval[col+'_R2'] = r2
        else:
            df_eval[col+'_mae'] = 0
            df_eval[col+'_mape'] = 0
            df_eval[col+'_rmse'] = 0
            df_eval[col+'_pears_corr'] = 0
            df_eval[col+'_R2'] = 0

    return df_eval



def secondary_opt(opt_params,df_data,fy_range,perf_eval_cols,predict_scaler=4,run_bayes=True,n_iter_bayes=10,bayes_var=0.1,df_prosp=None,prosp_coef=100,swap_target_to_fy21=False):
    '''
    Optimization and adjustements after running grid search.

    opt_params - dict
    	Region and OU groupings
    df_data	- Data Frame
    	Copy of training data
    fy_range - list
    	FY list
    perf_eval_cols - list
		Performace evaluation columns list
	predict_scaler - integer
		Scaler to adjust absolute prediction levels.
	run_bayes - boolean
		Flag to run bayesian optimizer
	n_iter_bayes - integer
		Number of bayes iterations
	bayes_var - float
		Defines search area for the bayesian search around initial grid-optimized parameters
	df_prosp - Data Frame
		If included, this will add small positive ACV predictions to the most promising prospects
	prosp_coef - integer
		Controls the prospect predictions. 
	swap_target_to_fy21 - boolean
		If true, target FY is forced to be 21. This is useful for some backtesting scenarios. 

    
    '''
    
    df_results = pd.DataFrame()
    df_summary_bayes = pd.DataFrame()
    
    for geo in opt_params.keys():
        for ou in opt_params[geo].keys():
            params = opt_params[geo][ou]
            logging.info('Running '+geo+' - '+ou)
            GRP = GROUPS[geo]
            groupings = GRP_QCP[geo] 
            for fy in fy_range:
                if geo == 'AMER':
                    df_dat = df_data.query('L4_RES_USER_NAME == @ou')
                else:
                    df_dat = df_data.query('L3_RES_USER_NAME == @ou')
                    
                if df_dat.shape[0] == 0:
                    continue
                    
                    
                cols = cols_by_fy(params.keys(), fy) 
                df_dat['Pred1'] = (df_dat[cols] * list(params.values())).sum(1)
                df_dat['Pred1'] = df_dat['Pred1']/predict_scaler # To reduce ACV sum differences
                
                # Fix negatives by just setting to zero
                df_dat['Pred1'] = np.where(df_dat['Pred1']<0,0,df_dat['Pred1'])
                
                # If prospect scores are around, apply them
                if df_prosp is not None:
                    df_prsp = df_prosp.query('FY == @fy')
                    if df_prsp.shape[0] > 0:
                        df_dat['ORG62_ACCOUNT_ID'] = df_dat['ORG62_ACCOUNT_ID'].str[:15] 
                        df_dat = df_dat.merge(df_prsp,left_on='ORG62_ACCOUNT_ID', right_on='ACCOUNT_ID', how='left')
                        df_dat['REVISED_SCORE']= df_dat['REVISED_SCORE'].fillna(0)
                        tmp = df_dat['Pred1'].sum()
                        df_dat['Pred1'] = df_dat['Pred1'] + (df_dat['REVISED_SCORE'] * prosp_coef)
                        prsp_add = df_dat['Pred1'].sum()-tmp
                        logging.info(ou+' - '+str(fy)+' added '+str(round(prsp_add/1000,2))+'K for prospects.')
                    
                    
                pred = df_dat['Pred1']
                
                if swap_target_to_fy21==True:
                    df_dat[f'CORE_ACV_T_M{fy}Y'] = df_dat['CORE_ACV_FY21']
                
                
                for grouping in GRP.keys():
            
                    # Get dist errors
                    dist_err = max_dist.dist_ou_raw_err(GRP[grouping][0], GRP[grouping][1]
                        ,df_dat.eval('best_predict_ = @pred'), f'CORE_ACV_T_M{fy}Y', perf_eval_cols[f"T_M{fy}Y"] + ['best_predict_'])
                    err_ser = dist_err[0]
                    
               
                    # Calculate win metrics and lift
                    df_eval = pd.DataFrame({'GEO':[geo],'OU':[ou],'FY':[fy],'Eval_Level':[grouping]
                                    ,'Pred1':[err_ser['best_predict__raw_err']],'T12M':[err_ser[f'CORE_T12_T_M{fy}Y_raw_err']]
                                    ,'T24M':[err_ser[f'CORE_T24_T_M{fy}Y_raw_err']],'T36M':[err_ser[f'CORE_T36_T_M{fy}Y_raw_err']]})
                    df_eval['W_T12']=np.where(df_eval['Pred1']<df_eval['T12M'],1,0)
                    df_eval['W_T24']=np.where(df_eval['Pred1']<df_eval['T24M'],1,0)
                    df_eval['W_T36']=np.where(df_eval['Pred1']<df_eval['T36M'],1,0)
                    df_eval['W_Margin']= (df_eval['T12M']+df_eval['T24M']+df_eval['T36M'])/3 - df_eval['Pred1']
                    df_eval['uplift'] = df_eval['W_Margin'] / df_eval['Pred1']
                    df_eval['Wins'] = df_eval['W_T12'] + df_eval['W_T24'] + df_eval['W_T36']
                    
                    
                    # Add regular metrics
                    df_dat_grp = pd.DataFrame(df_dat.groupby(GRP[grouping][1]).agg({f'CORE_ACV_T_M{fy}Y':['sum'],'Pred1':['sum']
                                                                                   ,f'CORE_T12_T_M{fy}Y':'sum',f'CORE_T24_T_M{fy}Y':'sum'
                                                                                   ,f'CORE_T36_T_M{fy}Y':'sum'}))
                    df_dat_grp.columns = ['Actual','Pred1','T12M','T24M','T36M']
                    
                    df_eval = reg_perf_metrics(df_dat_grp,df_eval)
                    df_eval['grid_params'] = str(params)
                    df_results = df_results.append(df_eval)
                    

            if run_bayes:
                search_space = {}
                for key in params.keys():
                        search_space[key] = hp.normal(key,params[key],abs(params[key]*bayes_var)+0.00000001) #Add a small fraction To avoid problems with zero weights

                grid_wins = df_results.query('OU == @ou')['Wins'].sum()
                bayes_params,bayes_score = optimize_performance_bayes(df_dat,fy_range,groupings[0],groupings[1],search_space,perf_eval_cols,n_iter=n_iter_bayes)
                df_summary_bayes  = df_summary_bayes.append(pd.DataFrame({'GEO':[geo],'OU':[ou],'Grid Wins':[grid_wins],'Bayes Wins':[round(bayes_score,0)],'grid_params':[params],'bayes_params':[bayes_params]}))  

                
    df_summary_bayes = df_summary_bayes.reset_index(drop=True)
    df_results = df_results.reset_index(drop=True)            
    return df_results,df_summary_bayes



def cols_by_fy(cols_template, fy):
    """
    Get FY Columns based on `cols_template`. 
    Make sure that each item in cols_template has only one format string option

    Parameters
    ----------
    cols: list
    Column name with template

    fy: int
    Fiscal year
    
    Returns
    -------
    list
        List of FY Columns
    
    """
    return [ x.format(fy) for x in cols_template]




def filter_best_param_from_grid(grid_param_res,is_train):
    """
    Uses grid_param_res results from AMER or INTL and summarizes the results 
    
    
    Parameters
    ----------
    grid_param_res : dataframe
        Data used to generate summary values. These contains all parameters grid search ran on.
    Returns
    -------
    Series, ser
        Uplift numbers
    """

    perf_eval_cols = perf_eval_cols_test
    if is_train == True:
    	perf_eval_cols = perf_eval_cols_train

    total_ou_param_perf = grid_param_res.groupby(
        ['OU', 'param_id'])[['performance', 'score']].sum().add_prefix('total_')

    # Get max performance idx
    best_score_ou_idx = total_ou_param_perf.groupby(
        level=['OU'])['total_score'].idxmax()
    summary_score = total_ou_param_perf.loc[best_score_ou_idx]
    
    # Get best score from grid_param_res
    best_param_grid_ou = grid_param_res.set_index(
        ['OU', 'param_id']).loc[best_score_ou_idx].reset_index()
    
    agg_cols = ['best_predict_'] + perf_eval_cols['eval_name']
    
    summary_type_grp = best_param_grid_ou.groupby(['OU','param_id','Type'])
    if is_train == True:
        summary_type_score = pd.concat([summary_type_grp[agg_cols].mean().assign(uplift = lambda x: x.apply(uplift_train,1)),summary_type_grp['performance'].sum()],1)
    else:
        summary_type_score = pd.concat([summary_type_grp[agg_cols].mean().assign(uplift = lambda x: x.apply(uplift_test,1)),summary_type_grp['performance'].sum()],1)
        
    
    return best_param_grid_ou.set_index(['OU','param_id',  'FY', 'Type']), summary_score,summary_type_score






def get_best_ou_summary(ou):
    """
    Get best summary  for `ou`
    
    returns Dataframe of summary results
    """
    if ou in amer_best_param_allfy.index.get_level_values('OU'):
        return amer_best_param_allfy.loc[ou]
    elif ou in intl_best_param_allfy.index.get_level_values('OU'):
        return intl_best_param_allfy.loc[ou]
    else:
        logging.error(ou +" Not part of runs!")
    return None


def get_best_ou_param():
    """
    Get best ou parameter based on `intl_best_param_allfy` and `amer_best_param_allfy`
    returns OU and Parameter values
    """
    return amer_best_param_allfy.groupby(level='OU')['param'].first().append(intl_best_param_allfy.groupby(level='OU')['param'].first())


# def ou_LevelHierarchy_eval_df(grp1, lvls, data, actual,  cols):
#     errors = []
#     for lvl in lvls:
#         err = max_dist.dist_ou_wt_err(grp1, lvl,  data, f'CORE_ACV_T_M{fy}Y', cols)[0]
#         errors.append(err)
#     df = pd.DataFrame(errors, index=pd.Index(lvls, name='Level'))
#     return df
    
    
# def get_relative_wins_by_cols(df_err_all_lvl, win_cols):
#     """
#     Comparing each prediction against other prediction to get relative wins.
    
#     Eg: Column `wins_TTM` describes How well TTM performed wrt other win_cols for each FY and Level
#     """
#     for w in win_cols:
#         df_err_all_lvl[f"wins_{w}"] = (df_err_all_lvl[win_cols].drop(w,1).apply(lambda x: df_err_all_lvl[w]<x)).sum(axis=1)
    
#     print("Relative wins for each model : ")
#     rel_wins = df_err_all_lvl.filter(regex='wins').sum()
#     #display(rel_wins/rel_wins.sum())
#     return df_err_all_lvl



# def build_predictions_backtest(inp_params,scaler,fy_range):
#     '''
    
    
#     '''
    
#     df_preds = pd.DataFrame()
#     for geo in inp_params.keys():
#         for ou in inp_params[geo].keys():
#             params = inp_params[geo][ou]
#             print(geo,ou)
#             GRP = GROUPS[geo]
#             groupings = GRP_QCP[geo] ## TODO: fix to use GRP

#             if geo == 'AMER':
#                     df_dat = data.query('L4_RES_USER_NAME == @ou')
#             else:
#                 df_dat = data.query('L3_RES_USER_NAME == @ou')
                
  
#             for fy in fy_range:
#                 cols = cols_by_fy(params.keys(), fy) 
#                 df_dat['Pred1'] = (df_dat[cols] * params.values()).sum(1)
#                 df_dat['Pred1'] = df_dat['Pred1'] / scaler

#                 # Fix negatives by just setting to zero
#                 df_dat[f'AI_MODEL_FY{fy}'] = np.where(df_dat['Pred1']<0,0,df_dat['Pred1'])
#                 df_dat[f'CORE_ACV_T_M{fy}Y'] = data[f'CORE_ACV_T_M{fy}Y']


#             df_preds = df_preds.append(df_dat)
            
#             print('ERROR -----NOT USING ------- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>!')
    

#     return df_preds[['ORG62_ACCOUNT_ID','RVP_TERRITORY','LEAF_TERR_NAME'
#                      ,'L3_RES_USER_NAME','L4_RES_USER_NAME','L5_RES_USER_NAME','L6_RES_USER_NAME'
#                      ,'L7_RES_USER_NAME','L8_RES_USER_NAME','CORE_ACV_FY19','CORE_ACV_FY20','CORE_ACV_FY21'
#                     ,'AI_MODEL_FY19','AI_MODEL_FY20','AI_MODEL_FY21']]




def perf_rep(df_results,metric='Wins/Uplift',grouping=['GEO','OU']):
	'''
		Utility function to build performance reports on different levels and with different contents
	'''
    if metric == 'Wins/Uplift':
        df_agg = df_results.groupby(grouping).agg({'Wins':['sum','mean'],'uplift':['mean']})
        df_agg.columns = ['Total Wins','Win %','Uplift %']
        df_agg['Win %'] = round((df_agg['Win %']/3)*100,1)
        return df_agg[['Total Wins','Win %','Uplift %']]
    elif metric == 'R2':
        return df_results[grouping + ['Pred1_R2','T12M_R2','T24M_R2','T36M_R2']].groupby(grouping).mean()
    elif metric == 'MAE':
        return df_results[grouping + ['Pred1_mae','T12M_mae','T24M_mae','T36M_mae']].groupby(grouping).mean()
    elif metric == 'MAPE':
        return df_results[grouping + ['Pred1_mape','T12M_mape','T24M_mape','T36M_mape']].groupby(grouping).mean()
    elif metric == 'Corr':
        return df_results[grouping + ['Pred1_pears_corr','T12M_pears_corr','T24M_pears_corr','T36M_pears_corr']].groupby(grouping).mean()


        
def build_params_from_res_df(res_amer,res_intl,is_train):
    '''
    Build parameter lists from optimization results

	res_amer - Data Frame
		AMER OU optimization results
	res_intl - Data Frame
		INTL OU optimization results
	is_train - boolean
		Controls the evaluation columns used
	Return
		Best parameters for AMER and INTL


    '''
    amer_res_param_grid = pd.concat(res_amer, ignore_index=True)
    amer_best_param_allfy, amer_summary_score, amer_summary_type_score = filter_best_param_from_grid(amer_res_param_grid,is_train)

    full_params_dict = {}
    best_params_dict = {}
    for ind,row in amer_best_param_allfy.reset_index().query('Type == "QCP" & FY == 1').iterrows():
        best_params_dict[row['OU']] = row['param']
    full_params_dict['AMER'] = best_params_dict
    
    intl_res_param_grid = pd.concat(res_intl, ignore_index=True)
    intl_best_param_allfy, intl_summary_score, intl_summary_type_score = filter_best_param_from_grid(intl_res_param_grid,is_train)


    best_params_dict = {}
    for ind,row in intl_best_param_allfy.reset_index().query('Type == "QCP" & FY == 1').iterrows():
        best_params_dict[row['OU']] = row['param']
    full_params_dict['INTL'] = best_params_dict
    
    return full_params_dict
    
        
        
        
def build_predictions_prod(data,GROUPS,GRP_QCP,inp_params,fy,predict_scaler=0.8,df_prosp=None,prosp_coef=100):
    '''
    Build predictions based on optimized parameters. 

	data - Data Frame
		Training/validation data
	GROUPS - dict
		Groupings for distribution accuracy calculation
	GRP_QCP - dict
		Groupings for distribution accuracy calculation - (Original QCP formatting) 
	inp_params - dict
		Metric weights from grid and bayesian searches. 
	fy - integer
		Prediction year (Relative to snap_dates)
	predict_scaler - integer
		Scaler to adjust absolute prediction levels.
	df_prosp - Data Frame
		If included, this will add small positive ACV predictions to the most promising prospects
	prosp_coef - integer
		Controls the prospect predictions. 

	Return
		Accounts with ACV predictions

     
    '''
    
    df_preds = pd.DataFrame()
    for geo in inp_params.keys():
        for ou in inp_params[geo].keys():
            params = inp_params[geo][ou]
            print(geo,ou)
            GRP = GROUPS[geo]
            groupings = GRP_QCP[geo] 

            if geo == 'AMER':
                df_dat = data.query('L4_RES_USER_NAME == @ou')
            else:
                df_dat = data.query('L3_RES_USER_NAME == @ou')
                
       
            df_dat['Pred1'] = predict_best_param(df_dat, fy, params)
            df_dat['Pred1'] = df_dat['Pred1']/predict_scaler # To reduce ACV sum differences

            # Fix negatives by just setting to zero
            df_dat['Pred1'] = np.where(df_dat['Pred1']<0,0,df_dat['Pred1'])
            
            
            if df_prosp is not None:
                df_prsp = df_prosp.query('FY == @fy')
                if df_prsp.shape[0] > 0:
                    df_dat['ORG62_ACCOUNT_ID'] = df_dat['ORG62_ACCOUNT_ID'].str[:15] 
                    df_dat = df_dat.merge(df_prsp,left_on='ORG62_ACCOUNT_ID', right_on='ACCOUNT_ID', how='left')
                    df_dat['ACCT_RAW_SCORE']= df_dat['ACCT_RAW_SCORE'].fillna(0)
                    tmp = df_dat['Pred1'].sum()
                    df_dat['Pred1'] = df_dat['Pred1'] + (df_dat['ACCT_RAW_SCORE'] * prosp_coef)
                    prsp_add = df_dat['Pred1'].sum()-tmp
                    logging.info(ou+' - '+str(fy)+' added '+str(round(prsp_add/1000,2))+'K for prospects.')
                else:
                    logging.warning(ou+' - '+str(fy)+' - No prospects added.')
                    
              
            df_dat[f'AI_MODEL_FY{fy}'] = np.where(df_dat['Pred1']<0,0,df_dat['Pred1'])
            df_preds = df_preds.append(df_dat[['ORG62_ACCOUNT_ID','LEAF_TERR_NAME'
                     ,'L3_RES_USER_NAME','L4_RES_USER_NAME','L5_RES_USER_NAME','L6_RES_USER_NAME'
                     ,'L7_RES_USER_NAME','L8_RES_USER_NAME',f'AI_MODEL_FY{fy}']])
            

    
    df_preds['PREDICTION_FY']=fy
    return df_preds





def get_params_dict(best_param_allfy):
	'''
	 Get best params dict from a results data frame.
	'''
    param_dct = {}
    ou = 'none'
    for i,row in best_param_allfy.reset_index(drop=False)[['OU','param']].iterrows():
        if row['OU'] != ou:
            param_dct[row['OU']]=row['param']
            ou = row['OU']

    return(param_dct)





# def backtest_fy_m1(opt_params,df_data,fy_range,perf_eval_cols,run_bayes=True,n_iter_bayes=10,bayes_var=0.1,df_prosp=None,prosp_coef=100,swap_target_to_fy21=False):
#     '''
    
    
#     '''
    
#     df_results = pd.DataFrame()
#     df_summary_bayes = pd.DataFrame()
    
#     for geo in opt_params.keys():
#         for ou in opt_params[geo].keys():
#             params = opt_params[geo][ou]
#             print(geo,ou)
#             GRP = GROUPS[geo]
#             groupings = GRP_QCP[geo] ## TODO: fix to use GRP
#             for fy in fy_range:
#                 if geo == 'AMER':
#                     df_dat = df_data.query('L4_RES_USER_NAME == @ou')
#                 else:
#                     df_dat = df_data.query('L3_RES_USER_NAME == @ou')
                    
#                 if df_dat.shape[0] == 0:
#                     continue
                    
                
                    
                    
#                 cols = cols_by_fy(params.keys(), fy) 
#                 df_dat['Pred1'] = (df_dat[cols] * list(params.values())).sum(1)
#                 df_dat['Pred1'] = df_dat['Pred1']/4 ################# <<<<<<<<<<<<<<<<<<, Check <<<<<
                
#                 # Fix negatives by just setting to zero
#                 df_dat['Pred1'] = np.where(df_dat['Pred1']<0,0,df_dat['Pred1'])
                
#                 # If prospect scores are around, apply them
#                 if df_prosp is not None:
#                     df_prsp = df_prosp.query('FY == @fy')
#                     if df_prsp.shape[0] > 0:
#                         df_dat['ORG62_ACCOUNT_ID'] = df_dat['ORG62_ACCOUNT_ID'].str[:15] 
#                         df_dat = df_dat.merge(df_prsp,left_on='ORG62_ACCOUNT_ID', right_on='ACCOUNT_ID', how='left')
#                         df_dat['REVISED_SCORE']= df_dat['REVISED_SCORE'].fillna(0)
#                         tmp = df_dat['Pred1'].sum()
#                         df_dat['Pred1'] = df_dat['Pred1'] + (df_dat['REVISED_SCORE'] * prosp_coef)
#                         prsp_add = df_dat['Pred1'].sum()-tmp
#                         print(ou,fy,'Added ',round(prsp_add/1000,2),'K for prospects.',sep='')

                    
#                 pred = df_dat['Pred1']
                
#                 if swap_target_to_fy21==True:
#                     df_dat[f'CORE_ACV_T_M{fy}Y'] = df_dat['CORE_ACV_FY21']
                
                
#                 for grouping in GRP.keys():
            
#                     # Geit dist errors
#                     dist_err = max_dist.dist_ou_raw_err(GRP[grouping][0], GRP[grouping][1]
#                         ,df_dat.eval('best_predict_ = @pred'), f'CORE_ACV_T_M{fy}Y', perf_eval_cols[f"T_M{fy}Y"] + ['best_predict_'])
#                     err_ser = dist_err[0]
                    
               
#                     # Calculate win metrics and lift
#                     df_eval = pd.DataFrame({'GEO':[geo],'OU':[ou],'FY':[fy],'Eval_Level':[grouping]
#                                     ,'Pred1':[err_ser['best_predict__raw_err']],'T12M':[err_ser[f'CORE_T12_T_M{fy}Y_raw_err']]
#                                     ,'T24M':[err_ser[f'CORE_T24_T_M{fy}Y_raw_err']],'T36M':[err_ser[f'CORE_T36_T_M{fy}Y_raw_err']]})
#                     df_eval['W_T12']=np.where(df_eval['Pred1']<df_eval['T12M'],1,0)
#                     df_eval['W_T24']=np.where(df_eval['Pred1']<df_eval['T24M'],1,0)
#                     df_eval['W_T36']=np.where(df_eval['Pred1']<df_eval['T36M'],1,0)
#                     df_eval['W_Margin']= (df_eval['T12M']+df_eval['T24M']+df_eval['T36M'])/3 - df_eval['Pred1']
#                     df_eval['uplift'] = df_eval['W_Margin'] / df_eval['Pred1']
#                     df_eval['Wins'] = df_eval['W_T12'] + df_eval['W_T24'] + df_eval['W_T36']
                    
                    
#                     # Add regular metrics
#                     df_dat_grp = pd.DataFrame(df_dat.groupby(GRP[grouping][1]).agg({f'CORE_ACV_T_M{fy}Y':['sum'],'Pred1':['sum']
#                                                                                    ,f'CORE_T12_T_M{fy}Y':'sum',f'CORE_T24_T_M{fy}Y':'sum'
#                                                                                    ,f'CORE_T36_T_M{fy}Y':'sum'}))
#                     df_dat_grp.columns = ['Actual','Pred1','T12M','T24M','T36M']
                    
#                     df_eval = reg_perf_metrics(df_dat_grp,df_eval)
#                     df_eval['grid_params'] = str(params)
#                     df_results = df_results.append(df_eval)
                    



#             if run_bayes:
#                 search_space = {}
#                 for key in params.keys():
#                         search_space[key] = hp.normal(key,params[key],abs(params[key]*bayes_var)+0.00000001) #Add a small fraction To avoid problems with zero weights

#                 grid_wins = df_results.query('OU == @ou')['Wins'].sum()
#                 bayes_params,bayes_score = optimize_performance_bayes(df_dat,fy_range,groupings[0],groupings[1],search_space,perf_eval_cols,n_iter=n_iter_bayes)
#                 df_summary_bayes  = df_summary_bayes.append(pd.DataFrame({'OU':[ou],'Grid Wins':[grid_wins],'Bayes Wins':[round(bayes_score,0)],'grid_params':[params],'bayes_params':[bayes_params]}))  

                
#     df_summary_bayes = df_summary_bayes.reset_index(drop=True)
#     df_results = df_results.reset_index(drop=True)            
#     return df_results,df_summary_bayes


    

## Script
def main():
	if len(sys.argv) < 1:
		print ('usage: python model_utils.py "snap_list"')
		return

	snap_month_input = sys.argv[1]
	snap_months = snap_month_input.split('|')


	logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s',level=logging.INFO)
	snap_month_input = sys.argv[1]
	logging.info('Snap list: '+snap_month_input)
	logging.info('Running for snaps: '+str(snap_months))


	# Set run params
	cmap = json.loads(open('data_utils.json').read())
	user_name = getpass.getuser()
	smds_lib_path = cmap['smds_lib_path'].replace('%user_name', user_name)
	ai4g_home = cmap['ai4g_home'].replace('%user_name', user_name)
	cred_file_path = cmap['cred_file_path'].replace('%user_name', user_name)
	dump_dir = ai4g_home + cmap['data_home'] + cmap['dump_dir'] 
	pricing_pred_file = cmap['pricing_pred']
	n_iter_grid = int(cmap['n_iter_grid'])


	if cmap['eval_in_sample'] == 'true':
	    perf_eval_cols_train = perf_eval_cols_full
	    perf_eval_cols_test = perf_eval_cols_full
	    FY_RANGE_TRAIN = FY_RANGE_FULL
	    FY_RANGE_VALID = FY_RANGE_FULL
    	logging.info('Evaluation within sample, using all data to predict.')
	else:
	    logging.info('Leaving last FY for validation.')


	GRP_QCP = flatten_groups(GROUPS)
	logging.info('AMER Groupings: '+str(GRP_QCP['AMER']))
	logging.info('INTL Groupings: '+str(GRP_QCP['INTL']))

	if 1 < 2:
		for snap_month_long in snap_months:
			logging.info('Starting snap: '+snap_month_long)


			snap_month = snap_month_long.replace('-','')
			data_file = f'aig4g_train_data_{snap_month_long}.csv'
			logging.info('data file: '+data_file)

			data_dir = dump_dir + snap_month+'/'
	
			logging.info("Reading file: "+data_dir+data_file)
			data = pd.read_csv(data_dir+data_file).fillna(0) 
			logging.info('Data shape: '+str(data.shape))


			# Get pricing data - This is NOT automatically downloaded (see pricing_pred parameter in the json file)
			logging.info("Reading pricing predictions file: "+pricing_pred_file)
			pricing_pred = pd.read_csv(pricing_pred_file).fillna(0)
			pricing_pred2 = pricing_pred[['ORG62_ACCOUNT_ID','CORE_PRED_FY21_SHRAVAN', 'CORE_PRED_FY20_SHRAVAN','CORE_PRED_FY19_SHRAVAN', 'CC_PRED_FY21_SHRAVAN','CC_PRED_FY20_SHRAVAN', 'CC_PRED_FY19_SHRAVAN', 'MC_PRED_FY21_SHRAVAN','MC_PRED_FY20_SHRAVAN', 'MC_PRED_FY19_SHRAVAN','TOTAL_PRED_FY20_SHRAVAN','TOTAL_PRED_FY21_SHRAVAN', 'TOTAL_PRED_FY19_SHRAVAN']]
			pricing_pred = None
			data = data.set_index('ORG62_ACCOUNT_ID').join(pricing_pred2.set_index('ORG62_ACCOUNT_ID'))
			pricing_pred2 = None
			pricng_col_map = {'TOTAL_PRED_FY21_SHRAVAN':'T_M0Y_PRICING_PRED','TOTAL_PRED_FY20_SHRAVAN':'T_M1Y_PRICING_PRED','TOTAL_PRED_FY19_SHRAVAN':'T_M2Y_PRICING_PRED','CORE_PRED_FY21_SHRAVAN':'T_M0Y_PRICING_PRED_CORE','CORE_PRED_FY20_SHRAVAN':'T_M1Y_PRICING_PRED_CORE','CORE_PRED_FY19_SHRAVAN':'T_M2Y_PRICING_PRED_CORE'}
			data = data.rename(columns=pricng_col_map)



			# Build lead segment column and secondary trailing months averages

			logging.info("Building TTM columns... ")
			data['lead_seg'] = data['L5_RES_USER_NAME'].astype(str).fillna("None") + ' ' +  data['PRIORTIZED_MARKETSEGMENT'].astype(str).fillna("None")

			data['CORE_T12_T_M0Y'] = data['CORE_ACV_T_M1Y']
			data['CORE_T12_T_M1Y'] = data['CORE_ACV_T_M2Y']
			data['CORE_T12_T_M2Y'] = data['CORE_ACV_T_M3Y']
			data['CORE_T12_T_M3Y'] = data['CORE_ACV_T_M4Y']

			data['CORE_T24_T_M0Y'] = (data['CORE_ACV_T_M1Y'] + data['CORE_ACV_T_M2Y'])/2
			data['CORE_T36_T_M0Y'] = (data['CORE_ACV_T_M1Y'] + data['CORE_ACV_T_M2Y'] + data['CORE_ACV_T_M3Y'])/3

			data['CORE_T24_T_M1Y'] = (data['CORE_ACV_T_M2Y'] + data['CORE_ACV_T_M3Y'])/2
			data['CORE_T36_T_M1Y'] = (data['CORE_ACV_T_M2Y'] + data['CORE_ACV_T_M3Y'] + data['CORE_ACV_T_M4Y'])/3

			data['CORE_T24_T_M2Y'] = (data['CORE_ACV_T_M3Y'] + data['CORE_ACV_T_M4Y'])/2
			data['CORE_T36_T_M2Y'] = (data['CORE_ACV_T_M3Y'] + data['CORE_ACV_T_M4Y'] + data['CORE_ACV_T_M5Y'])/3

			data['CORE_T24_T_M3Y'] = (data['CORE_ACV_T_M4Y'] + data['CORE_ACV_T_M5Y'])/2
			data['CORE_T36_T_M3Y'] = (data['CORE_ACV_T_M4Y'] + data['CORE_ACV_T_M5Y'] + data['CORE_ACV_T_M6Y'])/3

			data['CORE_T24_T_M4Y'] = (data['CORE_ACV_T_M5Y'] + data['CORE_ACV_T_M6Y'])/2
			data['CORE_T36_T_M4Y'] = (data['CORE_ACV_T_M5Y'] + data['CORE_ACV_T_M6Y'] + data['CORE_ACV_T_M7Y'])/3


			amer_ou_list = data.query('L3_RES_USER_NAME == "Andrew Kofoid"').L4_RES_USER_NAME.unique()
			other_ou_list = data.query('L3_RES_USER_NAME != "Andrew Kofoid"').L3_RES_USER_NAME.unique()

			logging.info('AMER OU list:'+str(amer_ou_list))
			logging.info('INTL OU list:'+str(other_ou_list))


			# Grid Search
			my_param_grid = my_param_grid_norm_range
			logging.info('Number of grid iterations: '+str(n_iter_grid))

			perf_eval_cols = perf_eval_cols_train
			fy_range = FY_RANGE_TRAIN 


			## AMER ##
			res = []
			AMER_GRP = GRP_QCP['AMER']
			for ou in amer_ou_list:
				res.append(optimize_performance( data.query(f'L4_RES_USER_NAME == "{ou}"'),fy_range, AMER_GRP[0],AMER_GRP[1],my_param_grid, perf_eval_cols, n_iter=n_iter_grid))
			    
			amer_res_param_grid = pd.concat(res, ignore_index=True)
			amer_best_param_allfy, amer_summary_score, amer_summary_type_score = filter_best_param_from_grid(amer_res_param_grid,is_train=True)


			## INTL ###
			res = []
			GRP = GRP_QCP['INTL']
			for ou in other_ou_list:
				if ou == 'Warren Wick':
					continue
				res.append(optimize_performance( data.query(f'L3_RES_USER_NAME == "{ou}"'),fy_range ,GRP[0],GRP[1],my_param_grid, perf_eval_cols, n_iter=n_iter_grid))
			    
			intl_res_param_grid = pd.concat(res, ignore_index=True)
			intl_best_param_allfy, intl_summary_score, intl_summary_type_score = filter_best_param_from_grid(intl_res_param_grid,is_train=True)

					
			# Store in-sample performance
			df_train_performance = amer_summary_type_score.reset_index(drop=False).append(intl_summary_type_score.reset_index(drop=False))
			df_train_performance.reset_index(drop=True)
			df_train_performance.to_csv(data_dir+'train_performance.csv',index=False)


			# Store best params dict
			amer_dict = get_params_dict(amer_best_param_allfy)
			intl_dict = get_params_dict(intl_best_param_allfy)
			full_params_dict = {}
			full_params_dict['AMER']=amer_dict
			full_params_dict['INTL']=intl_dict
			pickle.dump(full_params_dict, open( data_dir+"full_params_dict.pickle", "wb" ) )


			df_results,df_summary_bayes = backtest_fy_m1(full_params_dict,data,FY_RANGE_TEST,perf_eval_cols_test,run_bayes=False)


			df_results.to_csv(data_dir+'df_results.csv',index=False)

		logging.info('Done with snap '+snap_month)



if __name__ == '__main__':
    main()





