from datetime import datetime
from dateutil.relativedelta import relativedelta
import pandas as pd
import getpass
import json
import sys,os
import data_utils as data_utils




def main():
	if len(sys.argv) < 1:
		print ('usage: python ad_hoc_data.py "query file"')
		return


	query = sys.argv[1]
	print('Query file:',query)
	tgt_csv = query.split('.')[0] + '.csv'
	print('Target file:',tgt_csv)

	
    # Set run params
	cmap = json.loads(open('data_utils.json').read())
	# date_format = "%Y-%m-%d"
	# t_m0_date = snap_month
	# snap_dir = t_m0_date.replace('-','') + '/'
	# values_map = build_t_minus_dates(t_m0_date,date_format,8,add_TM0_date=True)

	user_name = getpass.getuser()
	smds_lib_path = cmap['smds_lib_path'].replace('%user_name', user_name)
	ai4g_home = cmap['ai4g_home'].replace('%user_name', user_name)
	cred_file_path = cmap['cred_file_path'].replace('%user_name', user_name)
	# snap_dir_path = ai4g_home + cmap['data_home'] + cmap['dump_dir'] + snap_dir 
	# sql_dir_path = ai4g_home + cmap['data_home'] + cmap['sql_dir'] + snap_dir 
	# template_dir_path  = ai4g_home + cmap['data_home'] + cmap['template_dir'] 
	adhoc_dir_path  = ai4g_home + cmap['data_home'] + cmap['adhoc_dir'] 


	# Create data directories
	data_utils.check_and_create_dir(adhoc_dir_path)

		
	adhoc_query = adhoc_dir_path + query
	adhoc_csv = adhoc_dir_path + tgt_csv


		
	sys.path.append(smds_lib_path)
	import db_etl as etl
	db_connection = etl.DB_ETL(cred_file_path)
	cursor = db_connection.oracle_connection()
	db_connection.run_sql_to_disk(cursor, adhoc_query, adhoc_csv, True, ',',print_debug=True)
	cursor.close()

	print('Done. Results stored to',adhoc_csv)


if __name__ == '__main__':
    main()


